# HealthCareGov Microservice Platform

## Architecture

| Service | Port | Database |
|---|---|---|
| discovery-server (Eureka) | 8761 | — |
| config-server | 8888 | — |
| api-gateway | 8080 | — |
| authentication-service | 8081 | hcg_users |
| user-service | 8082 | hcg_users |
| patient-service | 8083 | hcg_patients |
| hospital-service | 8084 | hcg_hospitals |
| appointment-service | 8085 | hcg_appointments |
| treatment-service | 8086 | hcg_treatments |
| notification-service | 8087 | hcg_notifications |
| compliance-service | 8088 | hcg_compliance |
| reporting-service | 8089 | hcg_reporting |

## Startup Order
1. discovery-server
2. config-server
3. user-service
4. notification-service
5. patient-service
6. hospital-service
7. appointment-service
8. treatment-service
9. compliance-service
10. reporting-service
11. authentication-service
12. api-gateway (last)

## API Endpoints (via Gateway on port 8080)

### Auth
- `POST /api/auth/login`

### Users
- `GET /api/users?status=Pending`
- `GET /api/users/{userId}`
- `PUT /api/users/{userId}/status?adminId={adminId}`

### Patients
- `POST /api/patients/register`
- `GET /api/patients/{patientId}`
- `PUT /api/patients/{patientId}`
- `POST /api/patients/documents`
- `GET /api/patients/{patientId}/history`
- `GET /api/patients/{patientId}/summary`

### Hospitals
- `POST /api/hospitals`
- `GET /api/hospitals`
- `GET /api/hospitals/{id}`
- `GET /api/hospitals/search?query=`
- `PUT /api/hospitals/{id}`
- `DELETE /api/hospitals/{id}`

### Resources
- `POST /api/resources`
- `GET /api/resources?hospitalId=`
- `GET /api/resources/{id}`
- `PUT /api/resources/{id}`
- `DELETE /api/resources/{id}`

### Schedules
- `POST /api/schedules`
- `PUT /api/schedules/{scheduleId}`
- `GET /api/schedules/doctor/{doctorId}`

### Appointments
- `POST /api/appointments/book`
- `PUT /api/appointments/cancel`
- `GET /api/appointments/doctor/{doctorId}`
- `GET /api/appointments`
- `PUT /api/appointments/{id}/reassign?adminId=`
- `PUT /api/appointments/{id}/checkin?adminId=`

### Treatments
- `POST /api/treatments`
- `PUT /api/treatments/patients/{patientId}`

### Compliance
- `POST /api/compliance?officerId=`
- `PUT /api/compliance/{id}?officerId=`
- `GET /api/compliance`

### Audits
- `POST /api/audits`
- `PUT /api/audits/{auditId}?requesterId=`
- `GET /api/audits?status=`
- `GET /api/audits/{auditId}`

### Notifications
- `GET /api/notifications/{userId}`

### Program / Reporting
- `GET /api/program/dashboard`
- `POST /api/program/reports`
- `GET /api/analytics/hospitals`
- `GET /api/analytics/reports/hospital-capacity`
- `GET /api/analytics/reports/resource-availability`
- `GET /api/analytics/reports/resource-distribution`

## Pre-Seeded Users

| Name | Email | Password | Role |
|---|---|---|---|
| Karthik | karthik09@gmail.com | karthik098 | ADMIN |
| Shashank | shashank09@gmail.com | shashank098 | ADMIN |
| Shiva | shiva09@gmail.com | shiva098 | DOCTOR |
| Akhil | akhil09@gmail.com | akhil098 | DOCTOR |
| Harshith | harshith09@gmail.com | harshith098 | PROGRAM_MANAGER |
| Krish | krish09@gmail.com | krish098 | PROGRAM_MANAGER |
| Mahendhar | mahendhar09@gmail.com | mahendhar098 | COMP_OFFICER |
| Priyank | priyank09@gmail.com | priyank098 | COMP_OFFICER |
| Vinay | vinay09@gmail.com | vinay098 | AUDITOR |
| Ayush | ayush09@gmail.com | ayush098 | AUDITOR |
