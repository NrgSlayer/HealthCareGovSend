package com.project.appointmentservice.client;
import com.project.appointmentservice.dto.UserClientDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
@FeignClient(name = "user-service")
public interface UserClient {
    @GetMapping("/api/users/{userId}")
    UserClientDto getUserById(@PathVariable Integer userId);
}
