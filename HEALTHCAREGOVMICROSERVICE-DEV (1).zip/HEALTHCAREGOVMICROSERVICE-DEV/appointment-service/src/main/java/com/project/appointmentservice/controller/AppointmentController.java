package com.project.appointmentservice.controller;
import com.project.appointmentservice.dto.*;
import com.project.appointmentservice.service.AppointmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@Slf4j
@RestController
@RequestMapping("/api/appointments")
@RequiredArgsConstructor
public class AppointmentController {
    private final AppointmentService appointmentService;
    @PostMapping("/book")
    public ResponseEntity<AppointmentResponse> book(@Valid @RequestBody AppointmentBookRequest req) {
        return new ResponseEntity<>(appointmentService.book(req), HttpStatus.CREATED);
    }
    @PutMapping("/cancel")
    public ResponseEntity<AppointmentResponse> cancel(@Valid @RequestBody AppointmentCancelRequest req) {
        return ResponseEntity.ok(appointmentService.cancel(req));
    }
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<AppointmentResponse>> getByDoctor(@PathVariable Integer doctorId) {
        return ResponseEntity.ok(appointmentService.getByDoctor(doctorId));
    }
    @GetMapping
    public ResponseEntity<List<AppointmentResponse>> getAll() { return ResponseEntity.ok(appointmentService.getAll()); }
    @PutMapping("/{appointmentId}/reassign")
    public ResponseEntity<AppointmentResponse> reassign(@PathVariable Integer appointmentId,
            @Valid @RequestBody AppointmentReassignRequest req, @RequestParam Integer adminId) {
        return ResponseEntity.ok(appointmentService.reassign(appointmentId, req.getNewDoctorId()));
    }
    @PutMapping("/{appointmentId}/checkin")
    public ResponseEntity<AppointmentResponse> checkIn(@PathVariable Integer appointmentId, @RequestParam Integer adminId) {
        return ResponseEntity.ok(appointmentService.checkIn(appointmentId));
    }
    @GetMapping("/count")
    public ResponseEntity<Long> countAll() { return ResponseEntity.ok(appointmentService.countAll()); }
    @GetMapping("/count-by-status")
    public ResponseEntity<Long> countByStatus(@RequestParam String status) { return ResponseEntity.ok(appointmentService.countByStatus(status)); }
}
