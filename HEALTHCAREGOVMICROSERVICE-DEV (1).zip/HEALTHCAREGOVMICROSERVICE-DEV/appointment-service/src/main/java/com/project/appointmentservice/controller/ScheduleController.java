package com.project.appointmentservice.controller;
import com.project.appointmentservice.dto.*;
import com.project.appointmentservice.service.ScheduleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/schedules")
@RequiredArgsConstructor
public class ScheduleController {
    private final ScheduleService scheduleService;
    @PostMapping
    public ResponseEntity<ScheduleResponse> create(@Valid @RequestBody ScheduleRequest req) {
        return new ResponseEntity<>(scheduleService.create(req), HttpStatus.CREATED);
    }
    @PutMapping("/{scheduleId}")
    public ResponseEntity<ScheduleResponse> update(@PathVariable Integer scheduleId, @Valid @RequestBody ScheduleRequest req) {
        return ResponseEntity.ok(scheduleService.update(scheduleId, req));
    }
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<ScheduleResponse>> getByDoctor(@PathVariable Integer doctorId) {
        return ResponseEntity.ok(scheduleService.getByDoctor(doctorId));
    }
}
