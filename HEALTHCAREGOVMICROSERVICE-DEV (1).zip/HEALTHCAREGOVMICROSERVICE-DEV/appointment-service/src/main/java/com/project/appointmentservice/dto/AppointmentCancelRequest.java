package com.project.appointmentservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class AppointmentCancelRequest {
    @NotNull @Min(1) private Integer appointmentID;
}
