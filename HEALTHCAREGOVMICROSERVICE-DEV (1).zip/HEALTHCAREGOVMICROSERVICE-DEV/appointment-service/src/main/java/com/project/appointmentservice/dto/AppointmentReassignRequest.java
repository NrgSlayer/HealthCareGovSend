package com.project.appointmentservice.dto;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
@Data
public class AppointmentReassignRequest {
    @NotNull private Integer newDoctorId;
}
