package com.project.appointmentservice.dto;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;
@Data @NoArgsConstructor @AllArgsConstructor
public class AppointmentResponse {
    private Integer appointmentID;
    private Integer patientID;
    private Integer doctorID;
    private Integer hospitalID;
    private LocalDate date;
    private LocalTime time;
    private String status;
}
