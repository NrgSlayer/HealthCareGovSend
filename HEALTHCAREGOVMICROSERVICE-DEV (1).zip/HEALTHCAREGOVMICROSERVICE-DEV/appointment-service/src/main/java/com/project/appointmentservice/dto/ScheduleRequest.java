package com.project.appointmentservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class ScheduleRequest {
    @NotNull private Integer doctorId;
    @NotNull private Integer hospitalId;
    @NotBlank private String availableDate;
    @NotBlank private String timeSlot;
}
