package com.project.appointmentservice.dto;
import lombok.*;
import java.time.LocalDate;
@Data @NoArgsConstructor @AllArgsConstructor
public class ScheduleResponse {
    private Integer scheduleID;
    private Integer doctorId;
    private Integer hospitalId;
    private LocalDate availableDate;
    private String timeSlot;
    private String status;
}
