package com.project.appointmentservice.dto;
import lombok.Data;
@Data
public class UserClientDto {
    private Integer userID;
    private String name;
    private String role;
    private String email;
    private String phone;
    private String status;
}
