package com.project.appointmentservice.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "appointment")
public class Appointment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer appointmentID;
    @Column(nullable=false) private Integer patientID;
    @Column(nullable=false) private Integer doctorID;
    @Column(nullable=false) private Integer hospitalID;
    @Column(nullable=false) private LocalDate date;
    @Column(nullable=false) private LocalTime time;
    @Column(nullable=false) private String status;
}
