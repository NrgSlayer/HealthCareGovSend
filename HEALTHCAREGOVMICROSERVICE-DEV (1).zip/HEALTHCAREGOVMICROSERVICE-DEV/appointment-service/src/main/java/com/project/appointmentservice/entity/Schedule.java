package com.project.appointmentservice.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "schedule",
    uniqueConstraints = @UniqueConstraint(name = "uk_schedule_doctor_date_slot",
        columnNames = {"doctorID","available_date","time_slot"}))
public class Schedule {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer scheduleID;
    @Column(name="doctorID", nullable=false) private Integer doctorID;
    @Column(name="hospitalID", nullable=false) private Integer hospitalID;
    @Column(name="available_date", nullable=false) private LocalDate availableDate;
    @Column(name="time_slot", nullable=false) private String timeSlot;
    @Column(nullable=false) private String status;
}
