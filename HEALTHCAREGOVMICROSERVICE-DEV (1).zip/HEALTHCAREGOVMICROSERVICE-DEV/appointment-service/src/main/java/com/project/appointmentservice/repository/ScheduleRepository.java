package com.project.appointmentservice.repository;
import com.project.appointmentservice.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
@Repository
public interface ScheduleRepository extends JpaRepository<Schedule, Integer> {
    Optional<Schedule> findByDoctorIDAndAvailableDateAndTimeSlot(Integer doctorId, LocalDate date, String timeSlot);
    List<Schedule> findByDoctorID(Integer doctorId);
}
