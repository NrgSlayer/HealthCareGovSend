package com.project.appointmentservice.service;

import com.project.appointmentservice.client.*;
import com.project.appointmentservice.dto.*;
import com.project.appointmentservice.entity.*;
import com.project.appointmentservice.exception.*;
import com.project.appointmentservice.repository.AppointmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AppointmentService {

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");

    private final AppointmentRepository appointmentRepository;
    private final ScheduleService scheduleService;
    private final NotificationClient notificationClient;
    private final UserClient userClient;

    @Transactional
    public AppointmentResponse book(AppointmentBookRequest req) {
        log.info("Booking appointment patientId={} doctorId={}", req.getPatientID(), req.getDoctorID());
        String formattedTime = req.getTime().format(TIME_FMT);
        Schedule slot = scheduleService.findSlot(req.getDoctorID(), req.getDate(), formattedTime);
        if (slot == null || !"Available".equalsIgnoreCase(slot.getStatus()))
            throw new BadRequestException("Selected time slot is not available for this doctor.");
        slot.setStatus("Booked");
        scheduleService.saveSlot(slot);
        Appointment appt = new Appointment();
        appt.setPatientID(req.getPatientID()); appt.setDoctorID(req.getDoctorID());
        appt.setHospitalID(req.getHospitalID()); appt.setDate(req.getDate());
        appt.setTime(req.getTime()); appt.setStatus("Confirmed");
        Appointment saved = appointmentRepository.save(appt);
        try {
            UserClientDto patient = userClient.getUserById(req.getPatientID());
            notificationClient.send(patient.getUserID(), saved.getAppointmentID(),
                    "Your appointment on " + req.getDate() + " at " + req.getTime() + " is confirmed.", "Appointment");
        } catch (Exception e) { log.warn("Notification failed: {}", e.getMessage()); }
        return toResponse(saved);
    }

    @Transactional
    public AppointmentResponse cancel(AppointmentCancelRequest req) {
        Appointment appt = findById(req.getAppointmentID());
        if ("Cancelled".equalsIgnoreCase(appt.getStatus()))
            throw new BadRequestException("Appointment is already cancelled.");
        String formattedTime = appt.getTime().format(TIME_FMT);
        Schedule slot = scheduleService.findSlot(appt.getDoctorID(), appt.getDate(), formattedTime);
        if (slot != null) { slot.setStatus("Available"); scheduleService.saveSlot(slot); }
        appt.setStatus("Cancelled");
        Appointment saved = appointmentRepository.save(appt);
        try {
            UserClientDto patient = userClient.getUserById(appt.getPatientID());
            notificationClient.send(patient.getUserID(), saved.getAppointmentID(),
                    "Your appointment on " + appt.getDate() + " has been cancelled.", "Appointment");
        } catch (Exception e) { log.warn("Notification failed: {}", e.getMessage()); }
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<AppointmentResponse> getByDoctor(Integer doctorId) {
        return appointmentRepository.findByDoctorID(doctorId).stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AppointmentResponse> getAll() {
        return appointmentRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional
    public AppointmentResponse reassign(Integer appointmentId, Integer newDoctorId) {
        Appointment appt = findById(appointmentId);
        if ("Cancelled".equalsIgnoreCase(appt.getStatus()))
            throw new BadRequestException("Cannot reassign a cancelled appointment.");
        appt.setDoctorID(newDoctorId);
        return toResponse(appointmentRepository.save(appt));
    }

    @Transactional
    public AppointmentResponse checkIn(Integer appointmentId) {
        Appointment appt = findById(appointmentId);
        if ("Cancelled".equalsIgnoreCase(appt.getStatus()))
            throw new BadRequestException("Cannot check in a cancelled appointment.");
        if ("Arrived".equalsIgnoreCase(appt.getStatus()))
            throw new BadRequestException("Patient is already checked in.");
        appt.setStatus("Arrived");
        return toResponse(appointmentRepository.save(appt));
    }

    @Transactional(readOnly = true)
    public long countAll() { return appointmentRepository.count(); }

    @Transactional(readOnly = true)
    public long countByStatus(String status) {
        return appointmentRepository.findAll().stream().filter(a -> status.equalsIgnoreCase(a.getStatus())).count();
    }

    private Appointment findById(Integer id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));
    }

    private AppointmentResponse toResponse(Appointment a) {
        return new AppointmentResponse(a.getAppointmentID(), a.getPatientID(), a.getDoctorID(),
                a.getHospitalID(), a.getDate(), a.getTime(), a.getStatus());
    }
}
