package com.project.appointmentservice.service;

import com.project.appointmentservice.dto.*;
import com.project.appointmentservice.entity.Schedule;
import com.project.appointmentservice.exception.*;
import com.project.appointmentservice.repository.ScheduleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ScheduleService {
    private final ScheduleRepository scheduleRepository;

    @Transactional
    public ScheduleResponse create(ScheduleRequest req) {
        LocalDate date = LocalDate.parse(req.getAvailableDate());
        if (scheduleRepository.findByDoctorIDAndAvailableDateAndTimeSlot(req.getDoctorId(), date, req.getTimeSlot()).isPresent())
            throw new BadRequestException("A slot already exists for this doctor on " + req.getAvailableDate() + " at " + req.getTimeSlot());
        Schedule s = new Schedule();
        s.setDoctorID(req.getDoctorId()); s.setHospitalID(req.getHospitalId());
        s.setAvailableDate(date); s.setTimeSlot(req.getTimeSlot()); s.setStatus("Available");
        return toResponse(scheduleRepository.save(s));
    }

    @Transactional
    public ScheduleResponse update(Integer scheduleId, ScheduleRequest req) {
        Schedule s = findById(scheduleId);
        if ("Booked".equalsIgnoreCase(s.getStatus()))
            throw new BadRequestException("Cannot edit a slot that is already Booked.");
        LocalDate newDate = LocalDate.parse(req.getAvailableDate());
        Optional<Schedule> conflict = scheduleRepository.findByDoctorIDAndAvailableDateAndTimeSlot(s.getDoctorID(), newDate, req.getTimeSlot());
        if (conflict.isPresent() && !conflict.get().getScheduleID().equals(scheduleId))
            throw new BadRequestException("A slot already exists for this doctor at that date and time.");
        s.setAvailableDate(newDate); s.setTimeSlot(req.getTimeSlot());
        return toResponse(scheduleRepository.save(s));
    }

    @Transactional(readOnly = true)
    public List<ScheduleResponse> getByDoctor(Integer doctorId) {
        return scheduleRepository.findByDoctorID(doctorId).stream().map(this::toResponse).collect(Collectors.toList());
    }

    public Schedule findSlot(Integer doctorId, LocalDate date, String timeSlot) {
        return scheduleRepository.findByDoctorIDAndAvailableDateAndTimeSlot(doctorId, date, timeSlot).orElse(null);
    }

    public void saveSlot(Schedule slot) { scheduleRepository.save(slot); }

    private Schedule findById(Integer id) {
        return scheduleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Schedule not found with id: " + id));
    }

    private ScheduleResponse toResponse(Schedule s) {
        return new ScheduleResponse(s.getScheduleID(), s.getDoctorID(), s.getHospitalID(),
                s.getAvailableDate(), s.getTimeSlot(), s.getStatus());
    }
}
