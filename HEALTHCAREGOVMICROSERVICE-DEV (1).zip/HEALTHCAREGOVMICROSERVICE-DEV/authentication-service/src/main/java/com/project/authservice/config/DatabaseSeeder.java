package com.project.authservice.config;

import com.project.authservice.entity.User;
import com.project.authservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class DatabaseSeeder implements CommandLineRunner {

    private final UserRepository userRepository;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) return;
        log.info("Seeding auth users...");

        String[][] users = {
            {"Karthik",  "ADMIN",           "karthik09@gmail.com",   "9999888871", "karthik098"},
            {"Shashank", "ADMIN",           "shashank09@gmail.com",  "9999888872", "shashank098"},
            {"Shiva",    "DOCTOR",          "shiva09@gmail.com",     "9999888873", "shiva098"},
            {"Akhil",    "DOCTOR",          "akhil09@gmail.com",     "9999888874", "akhil098"},
            {"Harshith", "PROGRAM_MANAGER", "harshith09@gmail.com",  "9999888875", "harshith098"},
            {"Krish",    "PROGRAM_MANAGER", "krish09@gmail.com",     "9999888876", "krish098"},
            {"Mahendhar","COMP_OFFICER",    "mahendhar09@gmail.com", "9999888877", "mahendhar098"},
            {"Priyank",  "COMP_OFFICER",    "priyank09@gmail.com",   "9999888878", "priyank098"},
            {"Vinay",    "AUDITOR",         "vinay09@gmail.com",     "9999888879", "vinay098"},
            {"Ayush",    "AUDITOR",         "ayush09@gmail.com",     "9999888880", "ayush098"}
        };

        for (String[] u : users) {
            User user = new User();
            user.setName(u[0]);
            user.setRole(u[1]);
            user.setEmail(u[2]);
            user.setPhone(u[3]);
            user.setPassword(u[4]);
            user.setStatus("Active");
            userRepository.save(user);
        }
        log.info("Seeded {} auth users", users.length);
    }
}
