package com.project.authservice.dto;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class LoginResponse {
    private Integer userID;
    private String name;
    private String email;
    private String role;
    private String status;
    private String message;
}
