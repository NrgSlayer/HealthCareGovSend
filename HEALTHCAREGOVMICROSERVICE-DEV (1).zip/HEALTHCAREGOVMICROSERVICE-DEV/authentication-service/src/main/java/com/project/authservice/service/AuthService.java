package com.project.authservice.service;

import com.project.authservice.dto.LoginRequest;
import com.project.authservice.dto.LoginResponse;
import com.project.authservice.entity.User;
import com.project.authservice.exception.BadRequestException;
import com.project.authservice.exception.ResourceNotFoundException;
import com.project.authservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;

    public LoginResponse login(LoginRequest req) {
        log.info("Login attempt for email={}", req.getEmail());
        User user = userRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new BadRequestException("Invalid email or password"));
        if (!user.getPassword().equals(req.getPassword())) {
            throw new BadRequestException("Invalid email or password");
        }
        if (!"Active".equalsIgnoreCase(user.getStatus()) && !"APPROVED".equalsIgnoreCase(user.getStatus())) {
            throw new BadRequestException("Account is not active. Current status: " + user.getStatus());
        }
        log.info("Login successful for userID={}", user.getUserID());
        return new LoginResponse(user.getUserID(), user.getName(),
                user.getEmail(), user.getRole(), user.getStatus(), "Login successful");
    }
}
