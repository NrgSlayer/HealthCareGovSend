package com.project.complianceservice.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
@FeignClient(name = "notification-service")
public interface NotificationClient {
    @PostMapping("/api/notifications/internal/send")
    void send(@RequestParam Integer userId,
              @RequestParam Integer entityId,
              @RequestParam String message,
              @RequestParam String category);
}
