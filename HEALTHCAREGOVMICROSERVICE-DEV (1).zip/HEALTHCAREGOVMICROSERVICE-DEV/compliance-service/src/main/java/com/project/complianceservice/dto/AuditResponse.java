package com.project.complianceservice.dto;
import lombok.*;
import java.time.LocalDate;
@Data @NoArgsConstructor @AllArgsConstructor
public class AuditResponse {
    private Integer auditID;
    private Integer officerId;
    private String scope;
    private String findings;
    private LocalDate date;
    private String status;
}
