package com.project.complianceservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class ComplianceRequest {
    @NotNull private Integer entityId;
    @NotBlank private String type;
    @NotBlank private String result;
    private String notes;
}
