package com.project.complianceservice.dto;
import lombok.*;
import java.time.LocalDate;
@Data @NoArgsConstructor @AllArgsConstructor
public class ComplianceResponse {
    private Integer complianceID;
    private Integer entityId;
    private String type;
    private String result;
    private LocalDate date;
    private String notes;
}
