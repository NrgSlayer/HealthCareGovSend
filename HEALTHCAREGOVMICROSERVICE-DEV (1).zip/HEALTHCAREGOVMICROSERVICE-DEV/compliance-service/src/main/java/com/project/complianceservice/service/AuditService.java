package com.project.complianceservice.service;

import com.project.complianceservice.dto.*;
import com.project.complianceservice.entity.Audit;
import com.project.complianceservice.exception.*;
import com.project.complianceservice.repository.AuditRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditService {
    private final AuditRepository auditRepository;

    @Transactional
    public AuditResponse create(AuditRequest req) {
        Audit audit = new Audit();
        audit.setOfficerId(req.getOfficerId()); audit.setScope(req.getScope());
        audit.setFindings(req.getFindings()); audit.setStatus("Scheduled");
        return toResponse(auditRepository.save(audit));
    }

    @Transactional
    public AuditResponse update(Integer auditId, AuditRequest req, Integer requesterId) {
        Audit audit = findById(auditId);
        if (req.getStatus() != null && !req.getStatus().isBlank()) {
            validateTransition(audit.getStatus(), req.getStatus());
            audit.setStatus(req.getStatus());
        }
        if (req.getFindings() != null) audit.setFindings(req.getFindings());
        return toResponse(auditRepository.save(audit));
    }

    @Transactional(readOnly = true)
    public List<AuditResponse> getAll(String status) {
        List<Audit> audits = (status != null && !status.isBlank())
                ? auditRepository.findByStatus(status) : auditRepository.findAll();
        return audits.stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AuditResponse getById(Integer auditId) { return toResponse(findById(auditId)); }

    private void validateTransition(String from, String to) {
        boolean valid = switch (from) {
            case "Scheduled" -> List.of("Scheduled","In-Progress").contains(to);
            case "In-Progress" -> List.of("In-Progress","Completed").contains(to);
            case "Completed" -> to.equals("Completed");
            default -> false;
        };
        if (!valid) throw new BadRequestException("Invalid status transition: " + from + " -> " + to);
    }

    private Audit findById(Integer id) {
        return auditRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Audit not found with id: " + id));
    }

    private AuditResponse toResponse(Audit a) {
        return new AuditResponse(a.getAuditID(), a.getOfficerId(), a.getScope(), a.getFindings(), a.getDate(), a.getStatus());
    }
}
