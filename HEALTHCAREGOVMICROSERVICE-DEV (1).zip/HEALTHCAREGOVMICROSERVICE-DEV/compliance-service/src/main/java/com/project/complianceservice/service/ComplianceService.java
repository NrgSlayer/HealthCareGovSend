package com.project.complianceservice.service;

import com.project.complianceservice.client.NotificationClient;
import com.project.complianceservice.dto.*;
import com.project.complianceservice.entity.ComplianceRecord;
import com.project.complianceservice.exception.*;
import com.project.complianceservice.repository.ComplianceRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ComplianceService {

    private static final Set<String> VALID_TYPES = Set.of("Appointment", "Treatment", "Hospital");
    private final ComplianceRecordRepository complianceRepository;
    private final NotificationClient notificationClient;

    @Transactional
    public ComplianceResponse create(ComplianceRequest req, Integer officerId) {
        if (!VALID_TYPES.contains(req.getType()))
            throw new BadRequestException("Invalid type. Allowed: Appointment, Treatment, Hospital");
        ComplianceRecord record = new ComplianceRecord();
        record.setEntityId(req.getEntityId()); record.setType(req.getType());
        record.setResult(req.getResult()); record.setNotes(req.getNotes());
        ComplianceRecord saved = complianceRepository.save(record);
        try {
            notificationClient.send(officerId, saved.getComplianceID(),
                    "Compliance record created for " + saved.getType() + " (EntityID: " + saved.getEntityId() + ").", "Compliance");
        } catch (Exception e) { log.warn("Notification failed: {}", e.getMessage()); }
        return toResponse(saved);
    }

    @Transactional
    public ComplianceResponse update(Integer id, ComplianceRequest req) {
        ComplianceRecord record = findById(id);
        record.setResult(req.getResult()); record.setNotes(req.getNotes());
        return toResponse(complianceRepository.save(record));
    }

    @Transactional(readOnly = true)
    public List<ComplianceResponse> search(String type, String result, Integer entityId, LocalDate startDate, LocalDate endDate) {
        return complianceRepository.search(type, result, entityId, startDate, endDate)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public long countAll() { return complianceRepository.count(); }

    @Transactional(readOnly = true)
    public long countByResult(String result) {
        return complianceRepository.findAll().stream().filter(c -> result.equalsIgnoreCase(c.getResult())).count();
    }

    private ComplianceRecord findById(Integer id) {
        return complianceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Compliance record not found with id: " + id));
    }

    private ComplianceResponse toResponse(ComplianceRecord c) {
        return new ComplianceResponse(c.getComplianceID(), c.getEntityId(), c.getType(), c.getResult(), c.getDate(), c.getNotes());
    }
}
