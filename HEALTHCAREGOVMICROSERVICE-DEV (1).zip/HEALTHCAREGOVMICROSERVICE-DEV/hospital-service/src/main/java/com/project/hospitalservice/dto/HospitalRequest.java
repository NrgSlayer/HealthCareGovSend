package com.project.hospitalservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class HospitalRequest {
    @NotBlank(message = "Hospital name is required") private String name;
    @NotBlank(message = "Location is required") private String location;
    @NotNull @Min(1) @Max(10000) private Integer capacity;
    @NotBlank(message = "Status is required") private String status;
}
