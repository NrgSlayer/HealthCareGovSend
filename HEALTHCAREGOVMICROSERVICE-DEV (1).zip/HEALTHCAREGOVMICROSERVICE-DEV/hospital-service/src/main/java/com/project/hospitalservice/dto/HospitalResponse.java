package com.project.hospitalservice.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor
public class HospitalResponse {
    private Integer hospitalID;
    private String name;
    private String location;
    private Integer capacity;
    private String status;
}
