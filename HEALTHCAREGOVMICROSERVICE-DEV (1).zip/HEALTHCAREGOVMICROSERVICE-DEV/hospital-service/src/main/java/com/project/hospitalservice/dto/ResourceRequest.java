package com.project.hospitalservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class ResourceRequest {
    @NotNull private Integer hospitalID;
    @NotBlank(message = "Resource type is required (Beds / Equipment / Staff)") private String type;
    @NotNull @Min(1) @Max(100000) private Integer quantity;
    @NotBlank private String status;
}
