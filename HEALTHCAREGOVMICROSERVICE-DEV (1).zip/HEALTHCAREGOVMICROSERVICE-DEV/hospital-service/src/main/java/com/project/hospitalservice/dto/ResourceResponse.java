package com.project.hospitalservice.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor
public class ResourceResponse {
    private Integer resourceID;
    private Integer hospitalID;
    private String hospitalName;
    private String type;
    private Integer quantity;
    private String status;
}
