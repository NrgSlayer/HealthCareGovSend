package com.project.notificationservice.controller;

import com.project.notificationservice.dto.NotificationResponse;
import com.project.notificationservice.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
public class NotificationController {
    private final NotificationService notificationService;

    @GetMapping("/api/notifications/{userId}")
    public ResponseEntity<List<NotificationResponse>> getForUser(@PathVariable Integer userId) {
        log.info("GET /api/notifications/{}", userId);
        return ResponseEntity.ok(notificationService.getForUser(userId));
    }

    @PostMapping("/api/notifications/internal/send")
    public ResponseEntity<Void> send(
            @RequestParam Integer userId,
            @RequestParam Integer entityId,
            @RequestParam String message,
            @RequestParam String category) {
        notificationService.send(userId, entityId, message, category);
        return ResponseEntity.ok().build();
    }
}
