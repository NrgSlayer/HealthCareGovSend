package com.project.notificationservice.dto;
import lombok.*;
import java.time.LocalDateTime;
@Data @NoArgsConstructor @AllArgsConstructor
public class NotificationResponse {
    private Integer notificationID;
    private Integer userId;
    private Integer entityId;
    private String message;
    private String category;
    private String status;
    private LocalDateTime createdDate;
}
