package com.project.notificationservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "notification")
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer notificationID;
    @Column(nullable=false) private Integer userID;
    private Integer entityId;
    @Column(nullable=false, columnDefinition="TEXT") private String message;
    @Column(nullable=false) private String category;
    @Column(nullable=false) private String status;
    @CreationTimestamp @Column(updatable=false) private LocalDateTime createdDate;
}
