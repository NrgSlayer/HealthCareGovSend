package com.project.notificationservice.exception;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> h1(ResourceNotFoundException ex) { return build(HttpStatus.NOT_FOUND, ex.getMessage()); }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> h2(Exception ex) { log.error("Unhandled: {}", ex.getMessage()); return build(HttpStatus.INTERNAL_SERVER_ERROR, "Error: "+ex.getMessage()); }
    private ResponseEntity<ErrorResponse> build(HttpStatus s, String msg) { return new ResponseEntity<>(new ErrorResponse(s.value(), msg, System.currentTimeMillis()), s); }
}
