package com.project.notificationservice.service;

import com.project.notificationservice.dto.NotificationResponse;
import com.project.notificationservice.entity.Notification;
import com.project.notificationservice.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationService {
    private final NotificationRepository notificationRepository;

    @Transactional
    public void send(Integer userId, Integer entityId, String message, String category) {
        Notification n = new Notification();
        n.setUserID(userId); n.setEntityId(entityId);
        n.setMessage(message); n.setCategory(category); n.setStatus("Unread");
        notificationRepository.save(n);
        log.info("Notification sent userId={} category={}", userId, category);
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> getForUser(Integer userId) {
        log.info("Fetching notifications userId={}", userId);
        return notificationRepository.findByUserID(userId).stream().map(this::toResponse).collect(Collectors.toList());
    }

    private NotificationResponse toResponse(Notification n) {
        return new NotificationResponse(n.getNotificationID(), n.getUserID(), n.getEntityId(),
                n.getMessage(), n.getCategory(), n.getStatus(), n.getCreatedDate());
    }
}
