package com.project.patientservice.client;

import com.project.patientservice.dto.MedicalSummaryResponse;
import com.project.patientservice.dto.TreatmentResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@FeignClient(name = "treatment-service")
public interface TreatmentClient {
    @GetMapping("/api/treatments/patients/{patientId}/history")
    List<TreatmentResponse> getMedicalHistory(@PathVariable Integer patientId);

    @GetMapping("/api/treatments/patients/{patientId}/summary")
    MedicalSummaryResponse getMedicalSummary(@PathVariable Integer patientId);
}
