package com.project.patientservice.client;

import com.project.patientservice.dto.CreateUserRequest;
import com.project.patientservice.dto.UserClientResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "user-service")
public interface UserClient {
    @PostMapping("/api/users/internal/create")
    UserClientResponse createUser(@RequestBody CreateUserRequest req);

    @GetMapping("/api/users/{userId}")
    UserClientResponse getUserById(@PathVariable Integer userId);
}
