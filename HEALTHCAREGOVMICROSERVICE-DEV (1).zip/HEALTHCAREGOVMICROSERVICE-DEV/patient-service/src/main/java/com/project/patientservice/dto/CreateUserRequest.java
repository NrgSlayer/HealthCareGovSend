package com.project.patientservice.dto;

import lombok.Data;

@Data
public class CreateUserRequest {
    private String name;
    private String role;
    private String email;
    private String phone;
    private String password;
    private String status;
}
