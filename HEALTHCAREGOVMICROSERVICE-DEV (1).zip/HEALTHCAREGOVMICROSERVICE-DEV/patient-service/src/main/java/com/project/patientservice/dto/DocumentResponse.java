package com.project.patientservice.dto;

import lombok.*;
import java.time.LocalDateTime;

@Data @NoArgsConstructor @AllArgsConstructor
public class DocumentResponse {
    private Integer documentID;
    private Integer patientID;
    private String docType;
    private String fileURI;
    private LocalDateTime uploadedDate;
    private String verificationStatus;
}
