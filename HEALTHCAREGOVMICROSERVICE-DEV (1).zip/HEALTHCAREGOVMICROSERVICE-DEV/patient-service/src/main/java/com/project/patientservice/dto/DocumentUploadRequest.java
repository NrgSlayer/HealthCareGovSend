package com.project.patientservice.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class DocumentUploadRequest {
    @NotNull(message = "Patient ID is required")
    private Integer patientID;
    @NotBlank(message = "Document type is required (IDProof / HealthCard)")
    private String docType;
    @NotBlank(message = "File URI is required")
    private String fileURI;
}
