package com.project.patientservice.dto;

import lombok.*;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor
public class MedicalSummaryResponse {
    private Integer recordID;
    private Integer patientID;
    private String detailsJSON;
    private LocalDate date;
    private String status;
}
