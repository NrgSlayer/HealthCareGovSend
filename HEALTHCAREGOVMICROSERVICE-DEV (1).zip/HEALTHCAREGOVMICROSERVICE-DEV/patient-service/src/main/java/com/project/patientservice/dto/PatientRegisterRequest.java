package com.project.patientservice.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class PatientRegisterRequest {
    @NotBlank(message = "Name is required")
    private String name;
    @NotBlank(message = "Date of birth is required (yyyy-MM-dd)")
    private String dob;
    @NotBlank(message = "Gender is required")
    private String gender;
    @NotBlank(message = "Address is required")
    private String address;
    @NotBlank(message = "Contact info is required")
    @Pattern(regexp = "\\d{10}", message = "Contact number must be exactly 10 digits")
    private String contactInfo;
    @Email(message = "Valid email is required")
    @NotBlank(message = "Email is required")
    private String email;
    @NotBlank(message = "Password is required")
    @Size(min = 8, message = "Password should be at least 8 characters")
    private String password;
}
