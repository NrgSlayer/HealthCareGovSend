package com.project.patientservice.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class PatientUpdateRequest {
    @NotBlank(message = "Address is required")
    private String address;
    @NotBlank(message = "Contact info is required")
    @Pattern(regexp = "\\d{10}", message = "Contact number must be exactly 10 digits")
    private String contactInfo;
}
