package com.project.patientservice.dto;

import lombok.*;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor
public class TreatmentResponse {
    private Integer treatmentID;
    private Integer patientID;
    private Integer doctorID;
    private String diagnosis;
    private String prescription;
    private String treatmentNotes;
    private LocalDate date;
    private String status;
}
