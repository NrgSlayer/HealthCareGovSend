package com.project.patientservice.dto;

import lombok.Data;

@Data
public class UserClientResponse {
    private Integer userID;
    private String name;
    private String role;
    private String email;
    private String phone;
    private String status;
}
