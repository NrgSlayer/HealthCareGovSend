package com.project.patientservice.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "patient")
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer patientID;
    private Integer userID;
    @Column(nullable = false)
    private String name;
    private LocalDate dob;
    private String gender;
    @Column(columnDefinition = "TEXT")
    private String address;
    private String contactInfo;
    @Column(nullable = false)
    private String status;
}
