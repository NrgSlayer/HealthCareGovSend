package com.project.patientservice.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "patient_document")
public class PatientDocument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer documentID;
    @Column(nullable = false)
    private Integer patientID;
    @Column(nullable = false)
    private String docType;
    @Column(nullable = false)
    private String fileURI;
    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime uploadedDate;
    @Column(nullable = false)
    private String verificationStatus;
}
