package com.project.patientservice.repository;

import com.project.patientservice.entity.PatientDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface PatientDocumentRepository extends JpaRepository<PatientDocument, Integer> {
    List<PatientDocument> findByPatientID(Integer patientId);
}
