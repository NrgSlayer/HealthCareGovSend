package com.project.patientservice.service;

import com.project.patientservice.client.TreatmentClient;
import com.project.patientservice.client.UserClient;
import com.project.patientservice.dto.*;
import com.project.patientservice.entity.Patient;
import com.project.patientservice.entity.PatientDocument;
import com.project.patientservice.exception.*;
import com.project.patientservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Slf4j
@Service
@RequiredArgsConstructor
public class PatientService {

    private static final Set<String> ALLOWED_DOC_TYPES = Set.of("IDProof", "HealthCard");

    private final PatientRepository patientRepository;
    private final PatientDocumentRepository documentRepository;
    private final UserClient userClient;
    private final TreatmentClient treatmentClient;

    @Transactional
    public PatientResponse register(PatientRegisterRequest req) {
        log.info("Registering patient email={}", req.getEmail());
        CreateUserRequest userReq = new CreateUserRequest();
        userReq.setName(req.getName());
        userReq.setRole("Patient");
        userReq.setEmail(req.getEmail());
        userReq.setPhone(req.getContactInfo());
        userReq.setPassword(req.getPassword());
        userReq.setStatus("Pending");
        UserClientResponse createdUser = userClient.createUser(userReq);

        Patient patient = new Patient();
        patient.setUserID(createdUser.getUserID());
        patient.setName(req.getName());
        patient.setDob(LocalDate.parse(req.getDob()));
        patient.setGender(req.getGender());
        patient.setAddress(req.getAddress());
        patient.setContactInfo(req.getContactInfo());
        patient.setStatus("Pending");
        Patient saved = patientRepository.save(patient);
        log.info("Patient registered patientID={}", saved.getPatientID());
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public PatientResponse getProfile(Integer patientId) {
        return toResponse(findById(patientId));
    }

    @Transactional
    public PatientResponse updateProfile(Integer patientId, PatientUpdateRequest req) {
        Patient patient = findById(patientId);
        patient.setAddress(req.getAddress());
        patient.setContactInfo(req.getContactInfo());
        return toResponse(patientRepository.save(patient));
    }

    @Transactional
    public DocumentResponse uploadDocument(DocumentUploadRequest req) {
        if (!ALLOWED_DOC_TYPES.contains(req.getDocType())) {
            throw new BadRequestException("Invalid docType. Allowed: IDProof, HealthCard");
        }
        findById(req.getPatientID());
        PatientDocument doc = new PatientDocument();
        doc.setPatientID(req.getPatientID());
        doc.setDocType(req.getDocType());
        doc.setFileURI(req.getFileURI());
        doc.setVerificationStatus("Pending");
        PatientDocument saved = documentRepository.save(doc);
        return new DocumentResponse(saved.getDocumentID(), saved.getPatientID(),
                saved.getDocType(), saved.getFileURI(), saved.getUploadedDate(), saved.getVerificationStatus());
    }

    @Transactional(readOnly = true)
    public List<TreatmentResponse> getMedicalHistory(Integer patientId) {
        findById(patientId);
        return treatmentClient.getMedicalHistory(patientId);
    }

    @Transactional(readOnly = true)
    public MedicalSummaryResponse getMedicalSummary(Integer patientId) {
        findById(patientId);
        return treatmentClient.getMedicalSummary(patientId);
    }

    @Transactional(readOnly = true)
    public PatientResponse getPatientByUserId(Integer userId) {
        return patientRepository.findByUserID(userId)
                .map(this::toResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found for userID: " + userId));
    }

    @Transactional
    public PatientResponse updateStatus(Integer patientId, String status) {
        Patient patient = findById(patientId);
        patient.setStatus(status);
        return toResponse(patientRepository.save(patient));
    }

    private Patient findById(Integer id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));
    }

    private PatientResponse toResponse(Patient p) {
        return new PatientResponse(p.getPatientID(), p.getUserID(), p.getName(),
                p.getDob(), p.getGender(), p.getAddress(), p.getContactInfo(), p.getStatus());
    }
}
