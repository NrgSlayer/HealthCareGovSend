package com.project.reportingservice.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
@FeignClient(name = "appointment-service")
public interface AppointmentClient {
    @GetMapping("/api/appointments/count")
    Long countAll();
    @GetMapping("/api/appointments/count-by-status")
    Long countByStatus(@RequestParam String status);
}
