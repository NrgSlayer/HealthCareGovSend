package com.project.reportingservice.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
@FeignClient(name = "compliance-service")
public interface ComplianceClient {
    @GetMapping("/api/compliance/count")
    Long countAll();
    @GetMapping("/api/compliance/count-by-result")
    Long countByResult(@RequestParam String result);
}
