package com.project.reportingservice.client;
import com.project.reportingservice.dto.HospitalDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@FeignClient(name = "hospital-service")
public interface HospitalClient {
    @GetMapping("/api/hospitals")
    List<HospitalDto> getAll();
    @GetMapping("/api/resources/sum-by-type")
    Long sumByType(@RequestParam String type);
}
