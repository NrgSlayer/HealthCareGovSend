package com.project.reportingservice.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
@FeignClient(name = "treatment-service")
public interface TreatmentClient {
    @GetMapping("/api/treatments/count")
    Long countAll();
    @GetMapping("/api/treatments/count-by-status")
    Long countByStatus(@RequestParam String status);
}
