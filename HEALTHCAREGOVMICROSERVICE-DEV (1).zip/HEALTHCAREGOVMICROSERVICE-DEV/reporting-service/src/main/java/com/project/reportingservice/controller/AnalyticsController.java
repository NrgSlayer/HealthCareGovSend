package com.project.reportingservice.controller;

import com.project.reportingservice.dto.AnalyticsResponse;
import com.project.reportingservice.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/analytics")
@RequiredArgsConstructor
public class AnalyticsController {
    private final AnalyticsService analyticsService;

    @GetMapping("/hospitals")
    public ResponseEntity<AnalyticsResponse> getHospitalAnalytics() { return ResponseEntity.ok(analyticsService.getHospitalAnalytics()); }
    @GetMapping("/reports/hospital-capacity")
    public ResponseEntity<Map<String,Object>> getCapacityReport() { return ResponseEntity.ok(analyticsService.getCapacityReport()); }
    @GetMapping("/reports/resource-availability")
    public ResponseEntity<Map<String,Object>> getAvailabilityReport() { return ResponseEntity.ok(analyticsService.getResourceAvailabilityReport()); }
    @GetMapping("/reports/resource-distribution")
    public ResponseEntity<Map<String,Object>> getDistributionReport() { return ResponseEntity.ok(analyticsService.getResourceDistributionReport()); }
}
