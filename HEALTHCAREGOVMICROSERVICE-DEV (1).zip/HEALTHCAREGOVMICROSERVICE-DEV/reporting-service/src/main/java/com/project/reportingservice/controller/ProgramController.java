package com.project.reportingservice.controller;

import com.project.reportingservice.dto.*;
import com.project.reportingservice.service.ProgramService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/program")
@RequiredArgsConstructor
public class ProgramController {
    private final ProgramService programService;

    @GetMapping("/dashboard")
    public ResponseEntity<DashboardResponse> getDashboard() {
        return ResponseEntity.ok(programService.getDashboard());
    }

    @PostMapping("/reports")
    public ResponseEntity<ReportResponse> generateReport(@Valid @RequestBody ReportRequest req) {
        return new ResponseEntity<>(programService.generateReport(req), HttpStatus.CREATED);
    }
}
