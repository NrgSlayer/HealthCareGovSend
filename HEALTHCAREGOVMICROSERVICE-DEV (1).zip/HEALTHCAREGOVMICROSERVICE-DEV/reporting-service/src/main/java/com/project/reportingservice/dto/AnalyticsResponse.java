package com.project.reportingservice.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor
public class AnalyticsResponse {
    private long totalHospitals;
    private long totalBeds;
    private long totalEquipment;
    private long totalStaff;
    private long totalCapacity;
}
