package com.project.reportingservice.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor
public class DashboardResponse {
    private long totalAppointments;
    private long confirmedAppointments;
    private long cancelledAppointments;
    private long totalTreatments;
    private long activeTreatments;
    private long completedTreatments;
    private long totalHospitals;
    private long totalCapacity;
    private long totalComplianceRecords;
    private long passedCompliance;
    private long failedCompliance;
}
