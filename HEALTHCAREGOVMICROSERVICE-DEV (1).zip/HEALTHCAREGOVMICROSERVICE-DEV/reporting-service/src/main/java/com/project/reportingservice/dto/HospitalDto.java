package com.project.reportingservice.dto;
import lombok.Data;
@Data
public class HospitalDto {
    private Integer hospitalID;
    private String name;
    private String location;
    private Integer capacity;
    private String status;
}
