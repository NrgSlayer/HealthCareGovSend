package com.project.reportingservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class ReportRequest {
    @NotNull private Integer hospitalId;
    @NotBlank private String scope;
}
