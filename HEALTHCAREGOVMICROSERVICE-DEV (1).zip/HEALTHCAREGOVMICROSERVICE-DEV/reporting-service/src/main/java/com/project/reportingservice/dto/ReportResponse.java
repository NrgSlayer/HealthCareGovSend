package com.project.reportingservice.dto;
import lombok.*;
import java.time.LocalDateTime;
@Data @NoArgsConstructor @AllArgsConstructor
public class ReportResponse {
    private Integer reportID;
    private Integer hospitalId;
    private String scope;
    private String metrics;
    private LocalDateTime generatedDate;
}
