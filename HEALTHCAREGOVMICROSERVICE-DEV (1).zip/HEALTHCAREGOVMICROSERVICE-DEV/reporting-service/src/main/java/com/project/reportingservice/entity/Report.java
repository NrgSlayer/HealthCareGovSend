package com.project.reportingservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "report")
public class Report {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer reportID;
    @Column(nullable=false) private Integer hospitalID;
    @Column(nullable=false) private String scope;
    @Column(columnDefinition="TEXT") private String metrics;
    @CreationTimestamp @Column(updatable=false) private LocalDateTime generatedDate;
}
