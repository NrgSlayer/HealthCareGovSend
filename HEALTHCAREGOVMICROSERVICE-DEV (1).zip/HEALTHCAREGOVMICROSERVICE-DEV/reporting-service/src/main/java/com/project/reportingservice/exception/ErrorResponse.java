package com.project.reportingservice.exception;
import lombok.*;
@Getter @AllArgsConstructor
public class ErrorResponse { private final int status; private final String message; private final long timestamp; }
