package com.project.reportingservice.service;

import com.project.reportingservice.client.*;
import com.project.reportingservice.dto.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class AnalyticsService {
    private final HospitalClient hospitalClient;

    public AnalyticsResponse getHospitalAnalytics() {
        List<HospitalDto> hospitals = hospitalClient.getAll();
        long totalHospitals = hospitals.size();
        long totalCapacity = hospitals.stream().mapToLong(h -> h.getCapacity() != null ? h.getCapacity() : 0L).sum();
        long totalBeds = hospitalClient.sumByType("Beds");
        long totalEquipment = hospitalClient.sumByType("Equipment");
        long totalStaff = hospitalClient.sumByType("Staff");
        return new AnalyticsResponse(totalHospitals, totalBeds, totalEquipment, totalStaff, totalCapacity);
    }

    public Map<String, Object> getCapacityReport() {
        List<HospitalDto> hospitals = hospitalClient.getAll();
        long total = hospitals.stream().mapToLong(h -> h.getCapacity() != null ? h.getCapacity() : 0L).sum();
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("totalCapacity", total);
        return report;
    }

    public Map<String, Object> getResourceAvailabilityReport() {
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("bedsAvailable", hospitalClient.sumByType("Beds"));
        report.put("equipmentAvailable", hospitalClient.sumByType("Equipment"));
        report.put("staffAvailable", hospitalClient.sumByType("Staff"));
        return report;
    }

    public Map<String, Object> getResourceDistributionReport() {
        return getResourceAvailabilityReport();
    }
}
