package com.project.reportingservice.service;

import com.project.reportingservice.client.*;
import com.project.reportingservice.dto.*;
import com.project.reportingservice.entity.Report;
import com.project.reportingservice.exception.*;
import com.project.reportingservice.repository.ReportRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProgramService {

    private static final Set<String> VALID_SCOPES = Set.of("Appointment","Treatment","Hospital","Compliance");

    private final AppointmentClient appointmentClient;
    private final TreatmentClient treatmentClient;
    private final HospitalClient hospitalClient;
    private final ComplianceClient complianceClient;
    private final ReportRepository reportRepository;

    public DashboardResponse getDashboard() {
        long totalAppts = appointmentClient.countAll();
        long confirmed = appointmentClient.countByStatus("Confirmed");
        long cancelled = appointmentClient.countByStatus("Cancelled");
        long totalTreatments = treatmentClient.countAll();
        long activeTreatments = treatmentClient.countByStatus("Active");
        long completedTreatments = treatmentClient.countByStatus("Completed");
        List<HospitalDto> hospitals = hospitalClient.getAll();
        long totalHospitals = hospitals.size();
        long totalCapacity = hospitals.stream().mapToLong(h -> h.getCapacity() != null ? h.getCapacity() : 0L).sum();
        long totalCompliance = complianceClient.countAll();
        long passedCompliance = complianceClient.countByResult("Pass");
        long failedCompliance = complianceClient.countByResult("Fail");
        return new DashboardResponse(totalAppts, confirmed, cancelled, totalTreatments, activeTreatments,
                completedTreatments, totalHospitals, totalCapacity, totalCompliance, passedCompliance, failedCompliance);
    }

    @Transactional
    public ReportResponse generateReport(ReportRequest req) {
        if (!VALID_SCOPES.contains(req.getScope()))
            throw new BadRequestException("Invalid scope. Allowed: Appointment, Treatment, Hospital, Compliance");
        String metrics = buildMetrics(req.getScope(), req.getHospitalId());
        Report report = new Report();
        report.setHospitalID(req.getHospitalId());
        report.setScope(req.getScope());
        report.setMetrics(metrics);
        Report saved = reportRepository.save(report);
        return new ReportResponse(saved.getReportID(), saved.getHospitalID(), saved.getScope(), saved.getMetrics(), saved.getGeneratedDate());
    }

    private String buildMetrics(String scope, Integer hospitalId) {
        return switch (scope) {
            case "Appointment" -> String.format("{\"scope\":\"Appointment\",\"hospitalId\":%d,\"confirmed\":%d,\"cancelled\":%d}", hospitalId, appointmentClient.countByStatus("Confirmed"), appointmentClient.countByStatus("Cancelled"));
            case "Treatment" -> String.format("{\"scope\":\"Treatment\",\"hospitalId\":%d,\"active\":%d,\"completed\":%d}", hospitalId, treatmentClient.countByStatus("Active"), treatmentClient.countByStatus("Completed"));
            case "Hospital" -> String.format("{\"scope\":\"Hospital\",\"hospitalId\":%d,\"beds\":%d,\"equipment\":%d,\"staff\":%d}", hospitalId, hospitalClient.sumByType("Beds"), hospitalClient.sumByType("Equipment"), hospitalClient.sumByType("Staff"));
            case "Compliance" -> String.format("{\"scope\":\"Compliance\",\"hospitalId\":%d,\"passed\":%d,\"failed\":%d}", hospitalId, complianceClient.countByResult("Pass"), complianceClient.countByResult("Fail"));
            default -> "{}";
        };
    }
}
