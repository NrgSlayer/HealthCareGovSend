package com.project.treatmentservice.client;
import com.project.treatmentservice.dto.PatientClientDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
@FeignClient(name = "patient-service")
public interface PatientClient {
    @GetMapping("/api/patients/{patientId}")
    PatientClientDto getPatientById(@PathVariable Integer patientId);
    @PutMapping("/api/patients/{patientId}/status")
    PatientClientDto updatePatientStatus(@PathVariable Integer patientId, @RequestParam String status);
}
