package com.project.treatmentservice.controller;

import com.project.treatmentservice.dto.*;
import com.project.treatmentservice.service.TreatmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/treatments")
@RequiredArgsConstructor
public class TreatmentController {
    private final TreatmentService treatmentService;

    @PostMapping
    public ResponseEntity<TreatmentResponse> record(@Valid @RequestBody TreatmentRequest req) {
        return new ResponseEntity<>(treatmentService.record(req), HttpStatus.CREATED);
    }

    @PutMapping("/patients/{patientId}")
    public ResponseEntity<PatientClientDto> updatePatientRecord(
            @PathVariable Integer patientId, @Valid @RequestBody MedicalRecordUpdateRequest req) {
        return ResponseEntity.ok(treatmentService.updatePatientRecord(patientId, req));
    }

    @GetMapping("/patients/{patientId}/history")
    public ResponseEntity<List<TreatmentResponse>> getMedicalHistory(@PathVariable Integer patientId) {
        return ResponseEntity.ok(treatmentService.getMedicalHistory(patientId));
    }

    @GetMapping("/patients/{patientId}/summary")
    public ResponseEntity<MedicalSummaryResponse> getMedicalSummary(@PathVariable Integer patientId) {
        return ResponseEntity.ok(treatmentService.getMedicalSummary(patientId));
    }

    @GetMapping("/count")
    public ResponseEntity<Long> countAll() { return ResponseEntity.ok(treatmentService.countAll()); }

    @GetMapping("/count-by-status")
    public ResponseEntity<Long> countByStatus(@RequestParam String status) {
        return ResponseEntity.ok(treatmentService.countByStatus(status));
    }
}
