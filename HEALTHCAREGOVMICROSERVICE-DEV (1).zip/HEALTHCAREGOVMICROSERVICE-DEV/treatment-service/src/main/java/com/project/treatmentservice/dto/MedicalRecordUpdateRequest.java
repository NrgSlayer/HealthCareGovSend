package com.project.treatmentservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class MedicalRecordUpdateRequest {
    @NotNull private Integer updaterId;
    @NotBlank private String name;
    @NotBlank private String contactInfo;
    @NotBlank private String status;
}
