package com.project.treatmentservice.dto;
import lombok.Data;
import java.time.LocalDate;
@Data
public class PatientClientDto {
    private Integer patientID;
    private Integer userID;
    private String name;
    private LocalDate dob;
    private String gender;
    private String address;
    private String contactInfo;
    private String status;
}
