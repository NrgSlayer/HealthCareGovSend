package com.project.treatmentservice.dto;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor
public class PatientUpdateRequest {
    private String address;
    private String contactInfo;
}
