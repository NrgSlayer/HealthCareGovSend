package com.project.treatmentservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class TreatmentRequest {
    @NotNull private Integer patientId;
    @NotNull private Integer doctorId;
    @NotBlank private String diagnosis;
    @NotBlank private String prescription;
    private String treatmentNotes;
    @NotBlank private String status;
}
