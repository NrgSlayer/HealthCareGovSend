package com.project.treatmentservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "medical_record")
public class MedicalRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer recordID;
    @Column(nullable=false, unique=true) private Integer patientID;
    @Column(columnDefinition="TEXT") private String detailsJSON;
    @CreationTimestamp @Column(updatable=false) private LocalDate date;
    private String status;
}
