package com.project.treatmentservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "treatment")
public class Treatment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer treatmentID;
    @Column(nullable=false) private Integer patientID;
    @Column(nullable=false) private Integer doctorID;
    @Column(nullable=false) private String diagnosis;
    @Column(nullable=false) private String prescription;
    @Column(columnDefinition="TEXT") private String treatmentNotes;
    @CreationTimestamp @Column(updatable=false) private LocalDate date;
    @Column(nullable=false) private String status;
}
