package com.project.treatmentservice.service;

import com.project.treatmentservice.client.*;
import com.project.treatmentservice.dto.*;
import com.project.treatmentservice.entity.*;
import com.project.treatmentservice.exception.*;
import com.project.treatmentservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class TreatmentService {

    private final TreatmentRepository treatmentRepository;
    private final MedicalRecordRepository medicalRecordRepository;
    private final PatientClient patientClient;
    private final NotificationClient notificationClient;

    @Transactional
    public TreatmentResponse record(TreatmentRequest req) {
        log.info("Recording treatment patientId={}", req.getPatientId());
        PatientClientDto patient = patientClient.getPatientById(req.getPatientId());
        Treatment t = new Treatment();
        t.setPatientID(req.getPatientId()); t.setDoctorID(req.getDoctorId());
        t.setDiagnosis(req.getDiagnosis()); t.setPrescription(req.getPrescription());
        t.setTreatmentNotes(req.getTreatmentNotes()); t.setStatus(req.getStatus());
        Treatment saved = treatmentRepository.save(t);

        MedicalRecord record = medicalRecordRepository.findByPatientID(req.getPatientId()).orElse(new MedicalRecord());
        record.setPatientID(req.getPatientId());
        String existing = record.getDetailsJSON() != null ? record.getDetailsJSON() : "";
        record.setDetailsJSON(existing + " | Diagnosis: " + saved.getDiagnosis());
        record.setStatus(saved.getStatus());
        medicalRecordRepository.save(record);

        try {
            if (patient.getUserID() != null) {
                notificationClient.send(patient.getUserID(), saved.getTreatmentID(),
                        "Treatment recorded — Diagnosis: " + saved.getDiagnosis(), "Treatment");
            }
        } catch (Exception e) { log.warn("Notification failed: {}", e.getMessage()); }

        return toResponse(saved);
    }

    @Transactional
    public PatientClientDto updatePatientRecord(Integer patientId, MedicalRecordUpdateRequest req) {
        PatientClientDto patient = patientClient.getPatientById(patientId);
        if ("Finalized".equalsIgnoreCase(patient.getStatus()))
            throw new BadRequestException("Cannot update a Finalized patient record.");
        return patientClient.updatePatientStatus(patientId, req.getStatus());
    }

    @Transactional(readOnly = true)
    public List<TreatmentResponse> getMedicalHistory(Integer patientId) {
        patientClient.getPatientById(patientId);
        return treatmentRepository.findByPatientID(patientId).stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public MedicalSummaryResponse getMedicalSummary(Integer patientId) {
        patientClient.getPatientById(patientId);
        MedicalRecord r = medicalRecordRepository.findByPatientID(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("No medical record for patientId: " + patientId));
        return new MedicalSummaryResponse(r.getRecordID(), r.getPatientID(), r.getDetailsJSON(), r.getDate(), r.getStatus());
    }

    @Transactional(readOnly = true)
    public long countAll() { return treatmentRepository.count(); }

    @Transactional(readOnly = true)
    public long countByStatus(String status) {
        return treatmentRepository.findAll().stream().filter(t -> status.equalsIgnoreCase(t.getStatus())).count();
    }

    private TreatmentResponse toResponse(Treatment t) {
        return new TreatmentResponse(t.getTreatmentID(), t.getPatientID(), t.getDoctorID(),
                t.getDiagnosis(), t.getPrescription(), t.getTreatmentNotes(), t.getDate(), t.getStatus());
    }
}
