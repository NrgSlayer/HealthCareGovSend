package com.project.userservice.controller;

import com.project.userservice.dto.*;
import com.project.userservice.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping
    public ResponseEntity<List<UserResponse>> getUsers(@RequestParam(required=false) String status) {
        return ResponseEntity.ok(userService.getUsers(status));
    }

    @GetMapping("/{userId}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable Integer userId) {
        return ResponseEntity.ok(userService.getUserById(userId));
    }

    @GetMapping("/by-email")
    public ResponseEntity<UserResponse> getUserByEmail(@RequestParam String email) {
        return ResponseEntity.ok(userService.getUserByEmail(email));
    }

    @PutMapping("/{userId}/status")
    public ResponseEntity<UserResponse> updateStatus(
            @PathVariable Integer userId,
            @Valid @RequestBody UserStatusRequest req,
            @RequestParam Integer adminId) {
        return ResponseEntity.ok(userService.updateStatus(userId, req, adminId));
    }

    @PostMapping("/internal/create")
    public ResponseEntity<UserResponse> createUser(@Valid @RequestBody CreateUserRequest req) {
        return new ResponseEntity<>(userService.createUser(req), HttpStatus.CREATED);
    }
}
