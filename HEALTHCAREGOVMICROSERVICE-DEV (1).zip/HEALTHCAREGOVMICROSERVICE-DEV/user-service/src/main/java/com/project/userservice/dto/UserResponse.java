package com.project.userservice.dto;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class UserResponse {
    private Integer userID;
    private String name;
    private String role;
    private String email;
    private String phone;
    private String status;
}
