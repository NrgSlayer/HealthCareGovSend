package com.project.userservice.service;

import com.project.userservice.dto.*;
import com.project.userservice.entity.User;
import com.project.userservice.exception.*;
import com.project.userservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private static final Set<String> VALID_STATUSES = Set.of("Active", "Inactive", "Rejected");

    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public List<UserResponse> getUsers(String status) {
        log.info("Fetching users status={}", status);
        List<User> users = (status != null && !status.isBlank())
                ? userRepository.findByStatus(status)
                : userRepository.findAll();
        return users.stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public UserResponse getUserById(Integer userId) {
        return toResponse(findById(userId));
    }

    @Transactional(readOnly = true)
    public UserResponse getUserByEmail(String email) {
        return toResponse(userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email)));
    }

    @Transactional
    public UserResponse updateStatus(Integer userId, UserStatusRequest req, Integer adminId) {
        log.info("Admin {} updating userId={} to status={}", adminId, userId, req.getStatus());
        if (!VALID_STATUSES.contains(req.getStatus())) {
            throw new BadRequestException("Invalid status. Allowed: Active, Inactive, Rejected");
        }
        User user = findById(userId);
        user.setStatus(req.getStatus());
        return toResponse(userRepository.save(user));
    }

    @Transactional
    public UserResponse createUser(CreateUserRequest req) {
        log.info("Creating user email={} role={}", req.getEmail(), req.getRole());
        if (userRepository.findByEmail(req.getEmail()).isPresent()) {
            throw new BadRequestException("Email already registered: " + req.getEmail());
        }
        User user = new User();
        user.setName(req.getName());
        user.setRole(req.getRole());
        user.setEmail(req.getEmail());
        user.setPhone(req.getPhone());
        user.setPassword(req.getPassword());
        user.setStatus(req.getStatus());
        return toResponse(userRepository.save(user));
    }

    private User findById(Integer id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    private UserResponse toResponse(User u) {
        return new UserResponse(u.getUserID(), u.getName(), u.getRole(),
                u.getEmail(), u.getPhone(), u.getStatus());
    }
}
