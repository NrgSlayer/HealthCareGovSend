# HealthCareGov MVP — Setup & Testing Guide

## Prerequisites
- Java 17+
- Maven 3.6+
- MySQL 8+

---

## 1. Database Setup

```sql
CREATE DATABASE IF NOT EXISTS healthcaregov;
```

No manual table creation needed — Spring Boot auto-creates all 14 tables on first run via `ddl-auto=update`.

---

## 2. Configure credentials

Edit `src/main/resources/application.properties` if your MySQL credentials differ:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/healthcaregov?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=root
```

---

## 3. Run the application

```bash
cd healthcaregov-mvp
./mvnw spring-boot:run
```

Server starts on: **http://localhost:9090**

---

## 4. Seed data (run these in order for a working test flow)

### Step 1 — Create a User (Admin/Doctor)
```
POST http://localhost:9090/api/users/login
```
> Note: You must INSERT a user directly into the DB first (no registration endpoint for system users):
```sql
INSERT INTO users (name, role, email, phone, status, password)
VALUES
  ('Admin User',   'Admin',  'admin@hcg.com',  '9000000001', 'Active', 'admin123'),
  ('Dr. Priya',    'Doctor', 'doctor@hcg.com', '9000000002', 'Active', 'doc123'),
  ('Compliance',   'Compliance', 'comp@hcg.com','9000000003', 'Active', 'comp123'),
  ('Auditor',      'Auditor','audit@hcg.com',  '9000000004', 'Active', 'aud123');
```

### Step 2 — Register a patient
```
POST /api/patients/register
{ "name":"Ravi Kumar","dob":"1990-05-15","gender":"Male","address":"Chennai","contactInfo":"9876543210" }
```

### Step 3 — Add a hospital
```
POST /api/hospitals
{ "name":"City Hospital","location":"Chennai","capacity":500,"status":"Active" }
```

### Step 4 — Add resources
```
POST /api/resources
{ "hospitalID":1,"type":"Beds","quantity":200,"status":"Available" }
```

### Step 5 — Add doctor schedule slot
```
POST /api/schedules
{ "doctorId":2,"hospitalId":1,"availableDate":"2025-12-25","timeSlot":"10:00:00" }
```

### Step 6 — Book appointment
```
POST /api/appointments/book
{ "patientID":1,"doctorID":2,"hospitalID":1,"date":"2025-12-25","time":"10:00:00" }
```

### Step 7 — Record treatment
```
POST /api/treatments
{ "patientId":1,"doctorId":2,"diagnosis":"Flu","prescription":"Paracetamol","treatmentNotes":"Rest advised","status":"Active" }
```

---

## 5. Validation rules reference

| Field | Rule |
|---|---|
| `contactInfo` | Exactly 10 digits |
| `docType` | `IDProof` or `HealthCard` only |
| `dob` | Format: `yyyy-MM-dd` |
| `availableDate` | Format: `yyyy-MM-dd` |
| `timeSlot` | Format: `HH:mm:ss` |
| Appointment `time` | Format: `HH:mm:ss` |
| Hospital `capacity` | 1 – 10,000 |
| Resource `quantity` | 1 – 100,000 |
| User `status` | `Active`, `Inactive`, `Rejected` |
| Compliance `type` | `Appointment`, `Treatment`, `Hospital` |
| Report `scope` | `Appointment`, `Treatment`, `Hospital`, `Compliance` |
| Audit status flow | `Scheduled → In-Progress → Completed` |

---

## 6. Key business rules

- **Booking**: Schedule slot must exist with `status=Available`. On book → slot becomes `Booked`, appointment becomes `Confirmed`.
- **Cancellation**: Appointment reverts slot to `Available`.
- **Duplicate slots**: Same doctorId + date + timeSlot is rejected.
- **Treatment update**: Only `Doctor` or `Admin` role. Blocked if patient status is `Finalized`.
- **Audit read-only**: Once `Completed`, only Auditor/Government_Auditor roles can update.
- **Notifications**: Auto-fired on appointment book/cancel (→ patient), treatment record (→ doctor), compliance create (→ officer).
- **Audit logs**: Written automatically on login, logout, status change, compliance create/update, audit create/update.

---

## 7. Error response format

All errors return:
```json
{
  "status": 400,
  "message": "Human-readable error message",
  "timestamp": 1700000000000
}
```

| HTTP Code | When |
|---|---|
| 400 | Validation failure, business rule violation |
| 404 | Entity not found |
| 500 | Unexpected server error |
