# HealthCareGov Microservices

## Tech Stack
- **Java 17** | **Spring Boot 4.0.5** | **Spring Cloud 2025.1.1**
- **JWT 0.10.0** | **Spring Security** | **OpenFeign** | **Resilience4j**
- **MySQL** | **Spring Data JPA** | **Eureka** | **API Gateway (WebFlux)**

## Services & Ports
| Service               | Port |
|-----------------------|------|
| discovery-server      | 8761 |
| config-server         | 8888 |
| api-gateway           | 8080 |
| authentication-service| 8081 |
| user-service          | 8082 |
| patient-service       | 8083 |
| appointment-service   | 8084 |
| hospital-service      | 8085 |
| treatment-service     | 8086 |
| notification-service  | 8087 |
| reporting-service     | 8088 |
| compliance-service    | 8089 |

## Startup Order
1. MySQL — create databases (auto-created with `createDatabaseIfNotExist=true`)
2. `discovery-server` (Eureka)
3. `config-server`
4. `api-gateway`
5. All other services (in any order)

## Default Database Credentials
```
spring.datasource.username=root
spring.datasource.password=root
```
Update `application.properties` in each service to match your MySQL credentials.

## Default Seed Users (authentication-service)
| Email                   | Password      | Role             |
|-------------------------|---------------|------------------|
| admin@hcgov.com         | Admin123!     | Admin            |
| doctor@hcgov.com        | Doctor123!    | Doctor           |
| auditor@hcgov.com       | Auditor123!   | Auditor          |
| compliance@hcgov.com    | Comply123!    | Comp_Officer     |
| manager@hcgov.com       | Manager123!   | Program_Manager  |

## Authentication
All requests (except `/api/auth/login` and `/api/patients/register`) require:
```
Authorization: Bearer <JWT_TOKEN>
```
Get token via: `POST /api/auth/login` through the API Gateway (port 8080).

## Key API Endpoints (via Gateway :8080)
### Auth
- `POST /api/auth/login` — Login, returns JWT

### Patients
- `POST /api/patients/register` — Register new patient
- `GET /api/patients/{patientId}` — View profile
- `PUT /api/patients/{patientId}` — Update profile
- `POST /api/patients/documents` — Upload document

### Appointments
- `GET /api/schedules/doctor/{doctorId}` — View doctor slots
- `POST /api/schedules` — Create schedule slot (Doctor)
- `POST /api/appointments/book` — Book appointment (Patient)
- `PUT /api/appointments/{id}/cancel` — Cancel appointment
- `PUT /api/appointments/{id}/checkin` — Check-in patient (Admin)
- `PUT /api/appointments/{id}/reassign?newDoctorId=X` — Reassign (Admin)

### Hospitals & Resources
- `POST /api/hospitals` — Add hospital (Admin)
- `GET /api/hospitals` — List hospitals
- `GET /api/hospitals/search?query=X` — Search hospitals
- `POST /api/resources` — Add resource (Admin)
- `GET /api/analytics/hospitals` — Analytics dashboard

### Treatments
- `POST /api/treatments` — Record treatment (Doctor)
- `GET /api/treatments/patient/{patientId}` — View history
- `PUT /api/treatments/patients/{patientId}` — Update patient record

### Users
- `GET /api/users` — List users (Admin)
- `PUT /api/users/{userId}/status?adminId=X` — Update user status

### Compliance & Audits
- `POST /api/compliance?officerId=X` — Create compliance record
- `GET /api/compliance` — Search/filter records
- `GET /api/compliance/audit-logs` — View audit logs
- `POST /api/audits` — Create audit
- `GET /api/audits` — List audits

### Notifications
- `GET /api/notifications/{userId}` — Get notifications
- `GET /api/notifications/{userId}/unread` — Unread only
- `PUT /api/notifications/{id}/read` — Mark as read

### Reports & Dashboard
- `GET /api/program/dashboard` — Program dashboard (Manager/Admin)
- `POST /api/program/reports` — Generate report
