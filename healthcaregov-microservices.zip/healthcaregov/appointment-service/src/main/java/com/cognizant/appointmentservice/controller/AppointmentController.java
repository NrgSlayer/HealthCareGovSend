package com.cognizant.appointmentservice.controller;

import com.cognizant.appointmentservice.dto.*;
import com.cognizant.appointmentservice.service.AppointmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/appointments") @RequiredArgsConstructor
public class AppointmentController {
    private final AppointmentService appointmentService;

    @PostMapping("/book")
    public ResponseEntity<AppointmentResponse> book(@Valid @RequestBody AppointmentBookRequest req) {
        return new ResponseEntity<>(appointmentService.book(req), HttpStatus.CREATED);
    }

    @PutMapping("/{appointmentId}/cancel")
    public ResponseEntity<AppointmentResponse> cancel(@PathVariable Integer appointmentId) {
        return ResponseEntity.ok(appointmentService.cancel(appointmentId));
    }

    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<AppointmentResponse>> getByDoctor(@PathVariable Integer doctorId) {
        return ResponseEntity.ok(appointmentService.getByDoctor(doctorId));
    }

    @GetMapping
    public ResponseEntity<List<AppointmentResponse>> getAll() {
        return ResponseEntity.ok(appointmentService.getAll());
    }

    @PutMapping("/{appointmentId}/reassign")
    public ResponseEntity<AppointmentResponse> reassign(
            @PathVariable Integer appointmentId, @RequestParam Integer newDoctorId) {
        return ResponseEntity.ok(appointmentService.reassign(appointmentId, newDoctorId));
    }

    @PutMapping("/{appointmentId}/checkin")
    public ResponseEntity<AppointmentResponse> checkIn(@PathVariable Integer appointmentId) {
        return ResponseEntity.ok(appointmentService.checkIn(appointmentId));
    }
}
