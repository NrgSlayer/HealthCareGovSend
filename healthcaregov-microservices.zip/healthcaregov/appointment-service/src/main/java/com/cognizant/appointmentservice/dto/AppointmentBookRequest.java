package com.cognizant.appointmentservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class AppointmentBookRequest {
    @NotNull @Min(1) private Integer patientID;
    @NotNull @Min(1) private Integer doctorID;
    @NotNull @Min(1) private Integer hospitalID;
    @NotNull private LocalDate date;
    @NotNull private LocalTime time;
}
