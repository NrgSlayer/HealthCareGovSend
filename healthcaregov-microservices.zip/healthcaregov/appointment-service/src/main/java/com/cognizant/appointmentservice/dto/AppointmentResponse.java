package com.cognizant.appointmentservice.dto;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Data @NoArgsConstructor @AllArgsConstructor
public class AppointmentResponse {
    private Integer appointmentID, patientID, doctorID, hospitalID;
    private String patientName, doctorName, hospitalName, status;
    private LocalDate date;
    private LocalTime time;
}
