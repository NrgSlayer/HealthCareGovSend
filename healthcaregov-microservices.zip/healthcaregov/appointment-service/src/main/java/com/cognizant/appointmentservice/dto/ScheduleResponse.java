package com.cognizant.appointmentservice.dto;
import lombok.*;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor
public class ScheduleResponse {
    private Integer scheduleID, doctorId, hospitalId;
    private String doctorName, hospitalName, timeSlot, status;
    private LocalDate availableDate;
}
