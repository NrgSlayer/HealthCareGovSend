package com.cognizant.appointmentservice.repository;
import com.cognizant.appointmentservice.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
    List<Appointment> findByDoctorUserID(Integer doctorId);
    List<Appointment> findByPatientPatientID(Integer patientId);
}
