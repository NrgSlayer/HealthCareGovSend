package com.cognizant.appointmentservice.repository;
import com.cognizant.appointmentservice.entity.Hospital;
import org.springframework.data.jpa.repository.JpaRepository;
public interface HospitalRepository extends JpaRepository<Hospital, Integer> {}
