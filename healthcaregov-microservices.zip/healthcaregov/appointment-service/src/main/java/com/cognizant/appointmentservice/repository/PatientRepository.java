package com.cognizant.appointmentservice.repository;
import com.cognizant.appointmentservice.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PatientRepository extends JpaRepository<Patient, Integer> {}
