package com.cognizant.appointmentservice.repository;
import com.cognizant.appointmentservice.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ScheduleRepository extends JpaRepository<Schedule, Integer> {
    Optional<Schedule> findByDoctorUserIDAndAvailableDateAndTimeSlot(Integer doctorId, LocalDate date, String timeSlot);
    List<Schedule> findByDoctorUserID(Integer doctorId);
}
