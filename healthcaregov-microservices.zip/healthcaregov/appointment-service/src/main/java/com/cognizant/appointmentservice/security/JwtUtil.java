package com.cognizant.appointmentservice.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {
    @Value("${jwt.secret}")
    private String secretKey;

    public String extractEmail(String token) {
        return Jwts.parser().setSigningKey(getKey()).parseClaimsJws(token).getBody().getSubject();
    }

    public boolean validateToken(String token, UserDetails ud) {
        try {
            return ud.getUsername().equals(extractEmail(token))
                && !Jwts.parser().setSigningKey(getKey()).parseClaimsJws(token)
                       .getBody().getExpiration().before(new Date());
        } catch (Exception e) { return false; }
    }

    private Key getKey() { return Keys.hmacShaKeyFor(secretKey.getBytes()); }
}
