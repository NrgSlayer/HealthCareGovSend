package com.cognizant.appointmentservice.service;

import com.cognizant.appointmentservice.dto.*;
import com.cognizant.appointmentservice.entity.*;
import com.cognizant.appointmentservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class AppointmentService {
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private final AppointmentRepository appointmentRepository;
    private final PatientRepository patientRepository;
    private final UserRepository userRepository;
    private final HospitalRepository hospitalRepository;
    private final ScheduleService scheduleService;

    @Transactional
    public AppointmentResponse book(AppointmentBookRequest req) {
        String formattedTime = req.getTime().format(TIME_FMT);
        Schedule slot = scheduleService.findSlot(req.getDoctorID(), req.getDate(), formattedTime);
        if (slot == null || !"Available".equalsIgnoreCase(slot.getStatus()))
            throw new RuntimeException("Selected time slot is not available for this doctor.");
        Patient patient = patientRepository.findById(req.getPatientID()).orElseThrow(() -> new RuntimeException("Patient not found: " + req.getPatientID()));
        User doctor = userRepository.findById(req.getDoctorID()).orElseThrow(() -> new RuntimeException("Doctor not found: " + req.getDoctorID()));
        Hospital hospital = hospitalRepository.findById(req.getHospitalID()).orElseThrow(() -> new RuntimeException("Hospital not found: " + req.getHospitalID()));
        slot.setStatus("Booked"); scheduleService.saveSlot(slot);
        Appointment appt = new Appointment(); appt.setPatient(patient); appt.setDoctor(doctor);
        appt.setHospital(hospital); appt.setDate(req.getDate()); appt.setTime(req.getTime()); appt.setStatus("Confirmed");
        return toResponse(appointmentRepository.save(appt));
    }

    @Transactional
    public AppointmentResponse cancel(Integer appointmentId) {
        Appointment appt = findById(appointmentId);
        if ("Cancelled".equalsIgnoreCase(appt.getStatus())) throw new RuntimeException("Appointment already cancelled.");
        String formattedTime = appt.getTime().format(TIME_FMT);
        Schedule slot = scheduleService.findSlot(appt.getDoctor().getUserID(), appt.getDate(), formattedTime);
        if (slot != null) { slot.setStatus("Available"); scheduleService.saveSlot(slot); }
        appt.setStatus("Cancelled");
        return toResponse(appointmentRepository.save(appt));
    }

    @Transactional(readOnly = true)
    public List<AppointmentResponse> getByDoctor(Integer doctorId) {
        return appointmentRepository.findByDoctorUserID(doctorId).stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AppointmentResponse> getAll() {
        return appointmentRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional
    public AppointmentResponse reassign(Integer appointmentId, Integer newDoctorId) {
        Appointment appt = findById(appointmentId);
        if ("Cancelled".equalsIgnoreCase(appt.getStatus())) throw new RuntimeException("Cannot reassign cancelled appointment.");
        User newDoctor = userRepository.findById(newDoctorId).orElseThrow(() -> new RuntimeException("Doctor not found: " + newDoctorId));
        appt.setDoctor(newDoctor);
        return toResponse(appointmentRepository.save(appt));
    }

    @Transactional
    public AppointmentResponse checkIn(Integer appointmentId) {
        Appointment appt = findById(appointmentId);
        if ("Cancelled".equalsIgnoreCase(appt.getStatus())) throw new RuntimeException("Cannot check in cancelled appointment.");
        if ("Arrived".equalsIgnoreCase(appt.getStatus())) throw new RuntimeException("Patient already checked in.");
        appt.setStatus("Arrived");
        return toResponse(appointmentRepository.save(appt));
    }

    private Appointment findById(Integer id) {
        return appointmentRepository.findById(id).orElseThrow(() -> new RuntimeException("Appointment not found: " + id));
    }

    private AppointmentResponse toResponse(Appointment a) {
        return new AppointmentResponse(a.getAppointmentID(), a.getPatient().getPatientID(),
            a.getDoctor().getUserID(), a.getHospital().getHospitalID(),
            a.getPatient().getName(), a.getDoctor().getName(), a.getHospital().getName(),
            a.getStatus(), a.getDate(), a.getTime());
    }
}
