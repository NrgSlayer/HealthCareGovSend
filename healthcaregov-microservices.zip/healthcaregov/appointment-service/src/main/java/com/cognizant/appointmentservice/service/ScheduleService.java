package com.cognizant.appointmentservice.service;

import com.cognizant.appointmentservice.dto.*;
import com.cognizant.appointmentservice.entity.*;
import com.cognizant.appointmentservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class ScheduleService {
    private final ScheduleRepository scheduleRepository;
    private final UserRepository userRepository;
    private final HospitalRepository hospitalRepository;

    @Transactional
    public ScheduleResponse create(ScheduleRequest req) {
        LocalDate date = LocalDate.parse(req.getAvailableDate());
        if (scheduleRepository.findByDoctorUserIDAndAvailableDateAndTimeSlot(req.getDoctorId(), date, req.getTimeSlot()).isPresent())
            throw new RuntimeException("Slot already exists for this doctor on " + req.getAvailableDate() + " at " + req.getTimeSlot());
        User doctor = userRepository.findById(req.getDoctorId()).orElseThrow(() -> new RuntimeException("Doctor not found: " + req.getDoctorId()));
        Hospital hospital = hospitalRepository.findById(req.getHospitalId()).orElseThrow(() -> new RuntimeException("Hospital not found: " + req.getHospitalId()));
        Schedule s = new Schedule(); s.setDoctor(doctor); s.setHospital(hospital);
        s.setAvailableDate(date); s.setTimeSlot(req.getTimeSlot()); s.setStatus("Available");
        return toResponse(scheduleRepository.save(s));
    }

    @Transactional
    public ScheduleResponse update(Integer scheduleId, ScheduleRequest req) {
        Schedule s = scheduleRepository.findById(scheduleId).orElseThrow(() -> new RuntimeException("Schedule not found: " + scheduleId));
        if ("Booked".equalsIgnoreCase(s.getStatus())) throw new RuntimeException("Cannot edit a booked slot");
        s.setAvailableDate(LocalDate.parse(req.getAvailableDate())); s.setTimeSlot(req.getTimeSlot());
        return toResponse(scheduleRepository.save(s));
    }

    @Transactional(readOnly = true)
    public List<ScheduleResponse> getByDoctor(Integer doctorId) {
        return scheduleRepository.findByDoctorUserID(doctorId).stream().map(this::toResponse).collect(Collectors.toList());
    }

    public Schedule findSlot(Integer doctorId, LocalDate date, String timeSlot) {
        return scheduleRepository.findByDoctorUserIDAndAvailableDateAndTimeSlot(doctorId, date, timeSlot).orElse(null);
    }

    public void saveSlot(Schedule slot) { scheduleRepository.save(slot); }

    private ScheduleResponse toResponse(Schedule s) {
        return new ScheduleResponse(s.getScheduleID(), s.getDoctor().getUserID(), s.getHospital().getHospitalID(),
            s.getDoctor().getName(), s.getHospital().getName(), s.getTimeSlot(), s.getStatus(), s.getAvailableDate());
    }
}
