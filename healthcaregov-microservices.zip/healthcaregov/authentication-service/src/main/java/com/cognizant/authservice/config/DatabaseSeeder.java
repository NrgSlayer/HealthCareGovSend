package com.cognizant.authservice.config;

import com.cognizant.authservice.entity.User;
import com.cognizant.authservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DatabaseSeeder implements CommandLineRunner {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() == 0) {
            seed("admin@hcgov.com", "Admin123!", "Admin", "Admin User", "9999000001");
            seed("doctor@hcgov.com", "Doctor123!", "Doctor", "Dr. Smith", "9999000002");
            seed("auditor@hcgov.com", "Auditor123!", "Auditor", "Audit Officer", "9999000003");
            seed("compliance@hcgov.com", "Comply123!", "Comp_Officer", "Compliance Officer", "9999000004");
            seed("manager@hcgov.com", "Manager123!", "Program_Manager", "Program Manager", "9999000005");
        }
    }

    private void seed(String email, String pass, String role, String name, String phone) {
        User u = new User();
        u.setEmail(email); u.setPassword(passwordEncoder.encode(pass));
        u.setRole(role); u.setName(name); u.setPhone(phone); u.setStatus("Active");
        userRepository.save(u);
    }
}
