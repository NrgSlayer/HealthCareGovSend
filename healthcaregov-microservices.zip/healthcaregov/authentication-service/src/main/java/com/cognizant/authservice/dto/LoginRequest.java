package com.cognizant.authservice.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class LoginRequest {
    @NotNull @Email
    private String email;
    @NotNull @Size(min = 8)
    private String password;
}
