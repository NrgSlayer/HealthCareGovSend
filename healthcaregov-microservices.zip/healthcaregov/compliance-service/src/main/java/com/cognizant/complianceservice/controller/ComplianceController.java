package com.cognizant.complianceservice.controller;

import com.cognizant.complianceservice.dto.*;
import com.cognizant.complianceservice.service.ComplianceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@RestController @RequestMapping("/api/compliance") @RequiredArgsConstructor
public class ComplianceController {
    private final ComplianceService complianceService;

    @PostMapping
    public ResponseEntity<ComplianceResponse> create(
            @Valid @RequestBody ComplianceRequest req, @RequestParam Integer officerId) {
        return new ResponseEntity<>(complianceService.create(req, officerId), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ComplianceResponse> update(
            @PathVariable Integer id, @Valid @RequestBody ComplianceRequest req,
            @RequestParam Integer officerId) {
        return ResponseEntity.ok(complianceService.update(id, req, officerId));
    }

    @GetMapping
    public ResponseEntity<List<ComplianceResponse>> search(
            @RequestParam(required=false) String type, @RequestParam(required=false) String result,
            @RequestParam(required=false) Integer entityId,
            @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return ResponseEntity.ok(complianceService.search(type, result, entityId, startDate, endDate));
    }

    @GetMapping("/audit-logs")
    public ResponseEntity<List<AuditLogResponse>> getAuditLogs() {
        return ResponseEntity.ok(complianceService.getAuditLogs());
    }
}
