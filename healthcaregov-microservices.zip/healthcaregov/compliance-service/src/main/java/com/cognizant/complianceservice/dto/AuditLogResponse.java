package com.cognizant.complianceservice.dto;
import lombok.*;
import java.time.Instant;

@Data @NoArgsConstructor @AllArgsConstructor
public class AuditLogResponse {
    private Integer auditLogID, userId;
    private String action, resource;
    private Instant timestamp;
}
