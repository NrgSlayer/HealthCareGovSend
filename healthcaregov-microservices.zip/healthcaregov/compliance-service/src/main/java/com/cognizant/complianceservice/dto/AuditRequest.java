package com.cognizant.complianceservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class AuditRequest {
    @NotNull private Integer officerId;
    @NotBlank private String scope;
    private String findings;
    private String status;
}
