package com.cognizant.complianceservice.dto;
import lombok.*;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor
public class AuditResponse {
    private Integer auditID, officerId;
    private String officerName, scope, findings, status;
    private LocalDate date;
}
