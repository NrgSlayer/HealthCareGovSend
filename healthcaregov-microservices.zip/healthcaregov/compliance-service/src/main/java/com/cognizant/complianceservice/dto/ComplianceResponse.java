package com.cognizant.complianceservice.dto;
import lombok.*;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor
public class ComplianceResponse {
    private Integer complianceID, entityId;
    private String type, result, notes;
    private LocalDate date;
}
