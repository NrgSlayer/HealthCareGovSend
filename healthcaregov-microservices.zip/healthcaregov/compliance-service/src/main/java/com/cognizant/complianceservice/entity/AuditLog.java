package com.cognizant.complianceservice.entity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.Instant;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Entity @Table(name = "compliance_audit_log")
public class AuditLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer auditLogID;
    @Column(name="user_id") private Integer userId;
    @Column(nullable=false) private String action;
    @Column(nullable=false) private String resource;
    @CreationTimestamp @Column(nullable=false, updatable=false) private Instant timestamp;
}
