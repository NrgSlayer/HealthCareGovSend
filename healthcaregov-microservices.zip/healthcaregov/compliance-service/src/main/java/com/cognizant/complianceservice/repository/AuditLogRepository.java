package com.cognizant.complianceservice.repository;
import com.cognizant.complianceservice.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AuditLogRepository extends JpaRepository<AuditLog, Integer> {}
