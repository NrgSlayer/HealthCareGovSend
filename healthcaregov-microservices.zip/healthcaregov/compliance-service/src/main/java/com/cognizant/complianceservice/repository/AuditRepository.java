package com.cognizant.complianceservice.repository;
import com.cognizant.complianceservice.entity.Audit;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface AuditRepository extends JpaRepository<Audit, Integer> {
    List<Audit> findByStatus(String status);
}
