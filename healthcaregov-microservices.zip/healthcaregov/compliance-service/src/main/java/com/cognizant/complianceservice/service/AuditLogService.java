package com.cognizant.complianceservice.service;

import com.cognizant.complianceservice.dto.AuditLogResponse;
import com.cognizant.complianceservice.entity.AuditLog;
import com.cognizant.complianceservice.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service @RequiredArgsConstructor
public class AuditLogService {
    private final AuditLogRepository auditLogRepository;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(Integer userId, String action, String resource) {
        AuditLog entry = new AuditLog();
        entry.setUserId(userId); entry.setAction(action); entry.setResource(resource);
        auditLogRepository.save(entry);
    }

    @Transactional(readOnly = true)
    public List<AuditLogResponse> getAllLogs() {
        return auditLogRepository.findAll().stream()
            .map(l -> new AuditLogResponse(l.getAuditLogID(), l.getUserId(), l.getAction(), l.getResource(), l.getTimestamp()))
            .collect(Collectors.toList());
    }
}
