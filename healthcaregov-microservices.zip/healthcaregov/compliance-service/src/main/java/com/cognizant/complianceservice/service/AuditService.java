package com.cognizant.complianceservice.service;

import com.cognizant.complianceservice.dto.*;
import com.cognizant.complianceservice.entity.Audit;
import com.cognizant.complianceservice.repository.AuditRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class AuditService {
    private final AuditRepository auditRepository;
    private final AuditLogService auditLogService;

    @Transactional
    public AuditResponse create(AuditRequest req) {
        Audit audit = new Audit();
        audit.setOfficerId(req.getOfficerId()); audit.setScope(req.getScope());
        audit.setFindings(req.getFindings()); audit.setStatus("Scheduled");
        Audit saved = auditRepository.save(audit);
        auditLogService.log(req.getOfficerId(), "CREATE_AUDIT", "Audit-" + saved.getAuditID());
        return toResponse(saved);
    }

    @Transactional
    public AuditResponse update(Integer auditId, AuditRequest req, Integer requesterId) {
        Audit audit = auditRepository.findById(auditId)
            .orElseThrow(() -> new RuntimeException("Audit not found: " + auditId));
        if (req.getStatus() != null && !req.getStatus().isBlank()) {
            validateTransition(audit.getStatus(), req.getStatus());
            audit.setStatus(req.getStatus());
        }
        if (req.getFindings() != null) audit.setFindings(req.getFindings());
        Audit saved = auditRepository.save(audit);
        auditLogService.log(requesterId, "UPDATE_AUDIT", "Audit-" + saved.getAuditID());
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<AuditResponse> getAll(String status) {
        List<Audit> audits = (status != null && !status.isBlank())
            ? auditRepository.findByStatus(status) : auditRepository.findAll();
        return audits.stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AuditResponse getById(Integer auditId) {
        return toResponse(auditRepository.findById(auditId)
            .orElseThrow(() -> new RuntimeException("Audit not found: " + auditId)));
    }

    private void validateTransition(String from, String to) {
        boolean valid = switch (from) {
            case "Scheduled" -> List.of("Scheduled","In-Progress").contains(to);
            case "In-Progress" -> List.of("In-Progress","Completed").contains(to);
            case "Completed" -> to.equals("Completed");
            default -> false;
        };
        if (!valid) throw new RuntimeException("Invalid status transition: " + from + " -> " + to +
            ". Allowed: Scheduled -> In-Progress -> Completed");
    }

    private AuditResponse toResponse(Audit a) {
        return new AuditResponse(a.getAuditID(), a.getOfficerId(), "Officer-"+a.getOfficerId(),
            a.getScope(), a.getFindings(), a.getStatus(), a.getDate());
    }
}
