package com.cognizant.complianceservice.service;

import com.cognizant.complianceservice.dto.*;
import com.cognizant.complianceservice.entity.ComplianceRecord;
import com.cognizant.complianceservice.repository.ComplianceRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class ComplianceService {
    private static final Set<String> VALID_TYPES = Set.of("Appointment","Treatment","Hospital");
    private final ComplianceRecordRepository complianceRepository;
    private final AuditLogService auditLogService;

    @Transactional
    public ComplianceResponse create(ComplianceRequest req, Integer officerId) {
        if (!VALID_TYPES.contains(req.getType()))
            throw new RuntimeException("Invalid type. Allowed: Appointment, Treatment, Hospital");
        ComplianceRecord record = new ComplianceRecord();
        record.setEntityId(req.getEntityId()); record.setType(req.getType());
        record.setResult(req.getResult()); record.setNotes(req.getNotes());
        ComplianceRecord saved = complianceRepository.save(record);
        auditLogService.log(officerId, "CREATE_COMPLIANCE", "ComplianceRecord-" + saved.getComplianceID());
        log.info("Compliance record created id={}", saved.getComplianceID());
        return toResponse(saved);
    }

    @Transactional
    public ComplianceResponse update(Integer id, ComplianceRequest req, Integer officerId) {
        ComplianceRecord record = complianceRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Compliance record not found: " + id));
        record.setResult(req.getResult()); record.setNotes(req.getNotes());
        ComplianceRecord saved = complianceRepository.save(record);
        auditLogService.log(officerId, "UPDATE_COMPLIANCE", "ComplianceRecord-" + saved.getComplianceID());
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<ComplianceResponse> search(String type, String result, Integer entityId,
            LocalDate startDate, LocalDate endDate) {
        return complianceRepository.search(type, result, entityId, startDate, endDate)
            .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AuditLogResponse> getAuditLogs() { return auditLogService.getAllLogs(); }

    private ComplianceResponse toResponse(ComplianceRecord c) {
        return new ComplianceResponse(c.getComplianceID(), c.getEntityId(), c.getType(),
            c.getResult(), c.getNotes(), c.getDate());
    }
}
