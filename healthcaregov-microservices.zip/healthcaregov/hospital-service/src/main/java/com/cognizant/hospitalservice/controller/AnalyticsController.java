package com.cognizant.hospitalservice.controller;

import com.cognizant.hospitalservice.dto.AnalyticsResponse;
import com.cognizant.hospitalservice.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/analytics") @RequiredArgsConstructor
public class AnalyticsController {
    private final AnalyticsService analyticsService;

    @GetMapping("/hospitals")
    public ResponseEntity<AnalyticsResponse> getHospitalAnalytics() {
        return ResponseEntity.ok(analyticsService.getHospitalAnalytics());
    }
}
