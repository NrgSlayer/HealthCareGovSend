package com.cognizant.hospitalservice.controller;

import com.cognizant.hospitalservice.dto.*;
import com.cognizant.hospitalservice.service.HospitalService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/hospitals") @RequiredArgsConstructor
public class HospitalController {
    private final HospitalService hospitalService;

    @PostMapping public ResponseEntity<HospitalResponse> create(@Valid @RequestBody HospitalRequest req) {
        return new ResponseEntity<>(hospitalService.create(req), HttpStatus.CREATED);
    }
    @GetMapping public ResponseEntity<List<HospitalResponse>> getAll() {
        return ResponseEntity.ok(hospitalService.getAll());
    }
    @GetMapping("/{id}") public ResponseEntity<HospitalResponse> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(hospitalService.getById(id));
    }
    @GetMapping("/search") public ResponseEntity<List<HospitalResponse>> search(@RequestParam String query) {
        return ResponseEntity.ok(hospitalService.search(query));
    }
    @PutMapping("/{id}") public ResponseEntity<HospitalResponse> update(
            @PathVariable Integer id, @Valid @RequestBody HospitalRequest req) {
        return ResponseEntity.ok(hospitalService.update(id, req));
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Integer id) {
        hospitalService.delete(id); return ResponseEntity.noContent().build();
    }
}
