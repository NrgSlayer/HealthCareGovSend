package com.cognizant.hospitalservice.dto;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class AnalyticsResponse {
    private long totalHospitals, totalBeds, totalEquipment, totalStaff, totalCapacity;
}
