package com.cognizant.hospitalservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class HospitalRequest {
    @NotBlank private String name;
    @NotBlank private String location;
    @NotNull @Min(1) @Max(10000) private Integer capacity;
    @NotBlank private String status;
}
