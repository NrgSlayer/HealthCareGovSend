package com.cognizant.hospitalservice.dto;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class HospitalResponse {
    private Integer hospitalID;
    private String name, location, status;
    private Integer capacity;
}
