package com.cognizant.hospitalservice.dto;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class ResourceResponse {
    private Integer resourceID, hospitalID, quantity;
    private String hospitalName, type, status;
}
