package com.cognizant.hospitalservice.repository;
import com.cognizant.hospitalservice.entity.Hospital;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface HospitalRepository extends JpaRepository<Hospital, Integer> {
    @Query("SELECT h FROM Hospital h WHERE LOWER(h.name) LIKE LOWER(CONCAT('%',:q,'%')) OR LOWER(h.location) LIKE LOWER(CONCAT('%',:q,'%'))")
    List<Hospital> search(@Param("q") String query);
}
