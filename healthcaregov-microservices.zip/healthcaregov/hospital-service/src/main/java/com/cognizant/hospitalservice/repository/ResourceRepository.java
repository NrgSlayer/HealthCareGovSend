package com.cognizant.hospitalservice.repository;
import com.cognizant.hospitalservice.entity.Resource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ResourceRepository extends JpaRepository<Resource, Integer> {
    List<Resource> findByHospitalHospitalID(Integer hospitalId);
    @Query("SELECT COALESCE(SUM(r.quantity),0) FROM Resource r WHERE r.type = :type")
    Long sumQuantityByType(@Param("type") String type);
}
