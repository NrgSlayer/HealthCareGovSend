package com.cognizant.hospitalservice.service;

import com.cognizant.hospitalservice.dto.AnalyticsResponse;
import com.cognizant.hospitalservice.repository.HospitalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service @RequiredArgsConstructor
public class AnalyticsService {
    private final HospitalRepository hospitalRepository;
    private final ResourceService resourceService;

    @Transactional(readOnly = true)
    public AnalyticsResponse getHospitalAnalytics() {
        long totalHospitals = hospitalRepository.count();
        long totalCapacity = hospitalRepository.findAll().stream()
            .mapToLong(h -> h.getCapacity() != null ? h.getCapacity() : 0L).sum();
        return new AnalyticsResponse(totalHospitals, resourceService.sumByType("Beds"),
            resourceService.sumByType("Equipment"), resourceService.sumByType("Staff"), totalCapacity);
    }
}
