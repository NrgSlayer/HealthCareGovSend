package com.cognizant.hospitalservice.service;

import com.cognizant.hospitalservice.dto.*;
import com.cognizant.hospitalservice.entity.*;
import com.cognizant.hospitalservice.repository.ResourceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class ResourceService {
    private final ResourceRepository resourceRepository;
    private final HospitalService hospitalService;

    @Transactional public ResourceResponse add(ResourceRequest req) {
        Hospital hospital = hospitalService.findById(req.getHospitalID());
        Resource r = new Resource(); r.setHospital(hospital); r.setType(req.getType());
        r.setQuantity(req.getQuantity()); r.setStatus(req.getStatus());
        return toResponse(resourceRepository.save(r));
    }

    @Transactional(readOnly = true) public List<ResourceResponse> getAll(Integer hospitalId) {
        List<Resource> list = hospitalId != null ? resourceRepository.findByHospitalHospitalID(hospitalId)
            : resourceRepository.findAll();
        return list.stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true) public ResourceResponse getById(Integer id) {
        return toResponse(findById(id));
    }

    @Transactional public ResourceResponse update(Integer id, ResourceRequest req) {
        Resource r = findById(id);
        if (req.getHospitalID() != null) r.setHospital(hospitalService.findById(req.getHospitalID()));
        r.setType(req.getType()); r.setQuantity(req.getQuantity()); r.setStatus(req.getStatus());
        return toResponse(resourceRepository.save(r));
    }

    @Transactional public void delete(Integer id) {
        if (!resourceRepository.existsById(id)) throw new RuntimeException("Resource not found: " + id);
        resourceRepository.deleteById(id);
    }

    public long sumByType(String type) {
        Long val = resourceRepository.sumQuantityByType(type); return val != null ? val : 0L;
    }

    private Resource findById(Integer id) {
        return resourceRepository.findById(id).orElseThrow(() -> new RuntimeException("Resource not found: " + id));
    }

    private ResourceResponse toResponse(Resource r) {
        return new ResourceResponse(r.getResourceID(), r.getHospital().getHospitalID(),
            r.getQuantity(), r.getHospital().getName(), r.getType(), r.getStatus());
    }
}
