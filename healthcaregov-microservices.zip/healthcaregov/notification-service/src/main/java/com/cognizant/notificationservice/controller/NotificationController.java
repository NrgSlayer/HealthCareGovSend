package com.cognizant.notificationservice.controller;

import com.cognizant.notificationservice.dto.*;
import com.cognizant.notificationservice.service.NotificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/notifications") @RequiredArgsConstructor
public class NotificationController {
    private final NotificationService notificationService;

    @PostMapping
    public ResponseEntity<NotificationResponse> send(@Valid @RequestBody NotificationRequest req) {
        return new ResponseEntity<>(notificationService.send(req), HttpStatus.CREATED);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<NotificationResponse>> getForUser(@PathVariable Integer userId) {
        return ResponseEntity.ok(notificationService.getForUser(userId));
    }

    @GetMapping("/{userId}/unread")
    public ResponseEntity<List<NotificationResponse>> getUnread(@PathVariable Integer userId) {
        return ResponseEntity.ok(notificationService.getUnreadForUser(userId));
    }

    @PutMapping("/{notificationId}/read")
    public ResponseEntity<NotificationResponse> markRead(@PathVariable Integer notificationId) {
        return ResponseEntity.ok(notificationService.markRead(notificationId));
    }
}
