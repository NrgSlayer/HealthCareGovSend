package com.cognizant.notificationservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class NotificationRequest {
    @NotNull private Integer userId;
    private Integer entityId;
    @NotBlank private String message;
    @NotBlank private String category;
}
