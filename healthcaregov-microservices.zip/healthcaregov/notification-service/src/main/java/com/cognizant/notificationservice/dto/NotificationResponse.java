package com.cognizant.notificationservice.dto;
import lombok.*;
import java.time.LocalDateTime;

@Data @NoArgsConstructor @AllArgsConstructor
public class NotificationResponse {
    private Integer notificationID, userId, entityId;
    private String message, category, status;
    private LocalDateTime createdDate;
}
