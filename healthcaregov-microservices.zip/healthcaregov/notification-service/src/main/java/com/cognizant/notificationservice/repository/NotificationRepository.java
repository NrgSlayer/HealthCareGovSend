package com.cognizant.notificationservice.repository;
import com.cognizant.notificationservice.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface NotificationRepository extends JpaRepository<Notification, Integer> {
    List<Notification> findByUserUserIDOrderByCreatedDateDesc(Integer userId);
    List<Notification> findByUserUserIDAndStatus(Integer userId, String status);
}
