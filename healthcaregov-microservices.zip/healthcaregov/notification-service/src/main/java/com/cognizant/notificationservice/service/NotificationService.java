package com.cognizant.notificationservice.service;

import com.cognizant.notificationservice.dto.*;
import com.cognizant.notificationservice.entity.*;
import com.cognizant.notificationservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class NotificationService {
    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    @Transactional
    public NotificationResponse send(NotificationRequest req) {
        User user = userRepository.findById(req.getUserId())
            .orElseThrow(() -> new RuntimeException("User not found: " + req.getUserId()));
        Notification n = new Notification();
        n.setUser(user); n.setEntityId(req.getEntityId());
        n.setMessage(req.getMessage()); n.setCategory(req.getCategory()); n.setStatus("Unread");
        Notification saved = notificationRepository.save(n);
        log.info("Notification sent userId={} category={}", req.getUserId(), req.getCategory());
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> getForUser(Integer userId) {
        return notificationRepository.findByUserUserIDOrderByCreatedDateDesc(userId)
            .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<NotificationResponse> getUnreadForUser(Integer userId) {
        return notificationRepository.findByUserUserIDAndStatus(userId, "Unread")
            .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional
    public NotificationResponse markRead(Integer notificationId) {
        Notification n = notificationRepository.findById(notificationId)
            .orElseThrow(() -> new RuntimeException("Notification not found: " + notificationId));
        n.setStatus("Read");
        return toResponse(notificationRepository.save(n));
    }

    private NotificationResponse toResponse(Notification n) {
        return new NotificationResponse(n.getNotificationID(), n.getUser().getUserID(),
            n.getEntityId(), n.getMessage(), n.getCategory(), n.getStatus(), n.getCreatedDate());
    }
}
