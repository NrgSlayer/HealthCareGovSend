package com.cognizant.patientservice.controller;

import com.cognizant.patientservice.dto.*;
import com.cognizant.patientservice.service.PatientService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/patients") @RequiredArgsConstructor
public class PatientController {
    private final PatientService patientService;

    @PostMapping("/register")
    public ResponseEntity<PatientResponse> register(@Valid @RequestBody PatientRegisterRequest req) {
        return new ResponseEntity<>(patientService.register(req), HttpStatus.CREATED);
    }

    @GetMapping("/{patientId}")
    public ResponseEntity<PatientResponse> getProfile(@PathVariable Integer patientId) {
        return ResponseEntity.ok(patientService.getProfile(patientId));
    }

    @PutMapping("/{patientId}")
    public ResponseEntity<PatientResponse> updateProfile(
            @PathVariable Integer patientId, @Valid @RequestBody PatientUpdateRequest req) {
        return ResponseEntity.ok(patientService.updateProfile(patientId, req));
    }

    @PostMapping("/documents")
    public ResponseEntity<DocumentResponse> uploadDocument(@Valid @RequestBody DocumentUploadRequest req) {
        return new ResponseEntity<>(patientService.uploadDocument(req), HttpStatus.CREATED);
    }
}
