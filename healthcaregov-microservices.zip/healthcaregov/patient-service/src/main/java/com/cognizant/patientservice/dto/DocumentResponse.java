package com.cognizant.patientservice.dto;
import lombok.*;
import java.time.LocalDateTime;

@Data @NoArgsConstructor @AllArgsConstructor
public class DocumentResponse {
    private Integer documentID, patientID;
    private String docType, fileURI, verificationStatus;
    private LocalDateTime uploadedDate;
}
