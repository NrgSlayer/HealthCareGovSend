package com.cognizant.patientservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class DocumentUploadRequest {
    @NotNull private Integer patientID;
    @NotBlank private String docType;
    @NotBlank private String fileURI;
}
