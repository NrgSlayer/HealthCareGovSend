package com.cognizant.patientservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class PatientRegisterRequest {
    @NotBlank private String name;
    @NotBlank private String dob;
    @NotBlank private String gender;
    @NotBlank private String address;
    @NotBlank @Pattern(regexp = "\\d{10}", message = "Must be 10 digits") private String contactInfo;
    @Email @NotBlank private String email;
    @NotBlank @Size(min=8) private String password;
}
