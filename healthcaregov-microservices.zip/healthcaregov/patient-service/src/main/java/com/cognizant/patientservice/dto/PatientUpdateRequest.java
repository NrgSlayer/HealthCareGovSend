package com.cognizant.patientservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class PatientUpdateRequest {
    @NotBlank private String address;
    @NotBlank @Pattern(regexp = "\\d{10}") private String contactInfo;
}
