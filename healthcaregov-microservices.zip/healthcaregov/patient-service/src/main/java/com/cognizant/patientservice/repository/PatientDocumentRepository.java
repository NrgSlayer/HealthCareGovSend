package com.cognizant.patientservice.repository;
import com.cognizant.patientservice.entity.PatientDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PatientDocumentRepository extends JpaRepository<PatientDocument, Integer> {
    List<PatientDocument> findByPatientPatientID(Integer patientId);
}
