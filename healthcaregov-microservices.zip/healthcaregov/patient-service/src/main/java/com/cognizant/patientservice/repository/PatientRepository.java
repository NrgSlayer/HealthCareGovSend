package com.cognizant.patientservice.repository;
import com.cognizant.patientservice.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PatientRepository extends JpaRepository<Patient, Integer> {
    Optional<Patient> findByUserUserID(Integer userId);
    Optional<Patient> findByUserEmail(String email);
}
