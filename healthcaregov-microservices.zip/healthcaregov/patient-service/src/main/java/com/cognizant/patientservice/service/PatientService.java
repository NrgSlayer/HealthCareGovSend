package com.cognizant.patientservice.service;

import com.cognizant.patientservice.dto.*;
import com.cognizant.patientservice.entity.*;
import com.cognizant.patientservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Set;

@Slf4j @Service @RequiredArgsConstructor
public class PatientService {
    private static final Set<String> ALLOWED_DOCS = Set.of("IDProof", "HealthCard");
    private final PatientRepository patientRepo;
    private final PatientDocumentRepository docRepo;
    private final UserRepository userRepo;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public PatientResponse register(PatientRegisterRequest req) {
        if (userRepo.findByEmail(req.getEmail()).isPresent())
            throw new RuntimeException("Email already registered: " + req.getEmail());
        User user = new User();
        user.setName(req.getName()); user.setRole("Patient");
        user.setEmail(req.getEmail()); user.setPhone(req.getContactInfo());
        user.setPassword(passwordEncoder.encode(req.getPassword())); user.setStatus("Pending");
        User savedUser = userRepo.save(user);

        Patient patient = new Patient();
        patient.setUser(savedUser); patient.setName(req.getName());
        patient.setDob(LocalDate.parse(req.getDob())); patient.setGender(req.getGender());
        patient.setAddress(req.getAddress()); patient.setContactInfo(req.getContactInfo());
        patient.setStatus("Pending");
        return toResponse(patientRepo.save(patient));
    }

    @Transactional(readOnly = true)
    public PatientResponse getProfile(Integer patientId) {
        return toResponse(findPatient(patientId));
    }

    @Transactional
    public PatientResponse updateProfile(Integer patientId, PatientUpdateRequest req) {
        Patient p = findPatient(patientId);
        p.setAddress(req.getAddress()); p.setContactInfo(req.getContactInfo());
        return toResponse(patientRepo.save(p));
    }

    @Transactional
    public DocumentResponse uploadDocument(DocumentUploadRequest req) {
        if (!ALLOWED_DOCS.contains(req.getDocType()))
            throw new RuntimeException("Invalid docType. Allowed: IDProof, HealthCard");
        Patient patient = findPatient(req.getPatientID());
        PatientDocument doc = new PatientDocument();
        doc.setPatient(patient); doc.setDocType(req.getDocType());
        doc.setFileURI(req.getFileURI()); doc.setVerificationStatus("Pending");
        PatientDocument saved = docRepo.save(doc);
        return new DocumentResponse(saved.getDocumentID(), patient.getPatientID(),
            saved.getDocType(), saved.getFileURI(), saved.getVerificationStatus(), saved.getUploadedDate());
    }

    private Patient findPatient(Integer id) {
        return patientRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Patient not found: " + id));
    }

    private PatientResponse toResponse(Patient p) {
        return new PatientResponse(p.getPatientID(),
            p.getUser() != null ? p.getUser().getUserID() : null,
            p.getName(), p.getGender(), p.getAddress(), p.getContactInfo(), p.getStatus(), p.getDob());
    }
}
