package com.cognizant.reportingservice.controller;

import com.cognizant.reportingservice.dto.*;
import com.cognizant.reportingservice.service.ProgramService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;

@RestController @RequestMapping("/api/program") @RequiredArgsConstructor
public class ProgramController {
    private final ProgramService programService;

    @GetMapping("/dashboard")
    public ResponseEntity<DashboardResponse> getDashboard(
            @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return ResponseEntity.ok(programService.getDashboard(startDate, endDate));
    }

    @PostMapping("/reports")
    public ResponseEntity<ReportResponse> generateReport(@Valid @RequestBody ReportRequest req) {
        return new ResponseEntity<>(programService.generateReport(req), HttpStatus.CREATED);
    }
}
