package com.cognizant.reportingservice.dto;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class DashboardResponse {
    private long totalAppointments, confirmedAppointments, cancelledAppointments;
    private long totalTreatments, activeTreatments, completedTreatments;
    private long totalHospitals, totalCapacity;
    private long totalComplianceRecords, passedCompliance, failedCompliance;
}
