package com.cognizant.reportingservice.dto;
import lombok.*;
import java.time.LocalDateTime;

@Data @NoArgsConstructor @AllArgsConstructor
public class ReportResponse {
    private Integer reportID, hospitalId;
    private String hospitalName, scope, metrics;
    private LocalDateTime generatedDate;
}
