package com.cognizant.reportingservice.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Entity @Table(name = "appointment")
public class Appointment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer appointmentID;
    private LocalDate date;
    private LocalTime time;
    private String status;
    @Column(name="patientID") private Integer patientID;
    @Column(name="doctorID") private Integer doctorID;
    @Column(name="hospitalID") private Integer hospitalID;
}
