package com.cognizant.reportingservice.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Entity @Table(name = "compliance_record")
public class ComplianceRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer complianceID;
    private Integer entityId;
    private String type, result, notes;
    private LocalDate date;
}
