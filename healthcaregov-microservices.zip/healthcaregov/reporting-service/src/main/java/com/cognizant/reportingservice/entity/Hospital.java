package com.cognizant.reportingservice.entity;
import jakarta.persistence.*;
import lombok.*;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Entity @Table(name = "hospital")
public class Hospital {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer hospitalID;
    private String name, location, status;
    private Integer capacity;
}
