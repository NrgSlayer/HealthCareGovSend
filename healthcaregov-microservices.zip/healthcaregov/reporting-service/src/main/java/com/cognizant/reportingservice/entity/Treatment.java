package com.cognizant.reportingservice.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Entity @Table(name = "treatment")
public class Treatment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer treatmentID;
    @Column(name="patientID") private Integer patientID;
    @Column(name="doctorID") private Integer doctorID;
    private String diagnosis, prescription, treatmentNotes, status;
    private LocalDate date;
}
