package com.cognizant.reportingservice.repository;
import com.cognizant.reportingservice.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {}
