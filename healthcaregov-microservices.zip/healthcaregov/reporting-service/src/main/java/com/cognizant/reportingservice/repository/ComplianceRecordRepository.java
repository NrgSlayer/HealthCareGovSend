package com.cognizant.reportingservice.repository;
import com.cognizant.reportingservice.entity.ComplianceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ComplianceRecordRepository extends JpaRepository<ComplianceRecord, Integer> {}
