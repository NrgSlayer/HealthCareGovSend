package com.cognizant.reportingservice.repository;
import com.cognizant.reportingservice.entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ReportRepository extends JpaRepository<Report, Integer> {}
