package com.cognizant.reportingservice.repository;
import com.cognizant.reportingservice.entity.Treatment;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TreatmentRepository extends JpaRepository<Treatment, Integer> {}
