package com.cognizant.reportingservice.service;

import com.cognizant.reportingservice.dto.*;
import com.cognizant.reportingservice.entity.*;
import com.cognizant.reportingservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.Set;

@Slf4j @Service @RequiredArgsConstructor
public class ProgramService {
    private static final Set<String> VALID_SCOPES = Set.of("Appointment","Treatment","Hospital","Compliance");
    private final AppointmentRepository appointmentRepository;
    private final TreatmentRepository treatmentRepository;
    private final HospitalRepository hospitalRepository;
    private final ComplianceRecordRepository complianceRepository;
    private final ReportRepository reportRepository;

    @Transactional(readOnly = true)
    public DashboardResponse getDashboard(LocalDate startDate, LocalDate endDate) {
        long totalAppts = appointmentRepository.count();
        long confirmed = appointmentRepository.findAll().stream()
            .filter(a -> "Confirmed".equalsIgnoreCase(a.getStatus()))
            .filter(a -> inRange(a.getDate(), startDate, endDate)).count();
        long cancelled = appointmentRepository.findAll().stream()
            .filter(a -> "Cancelled".equalsIgnoreCase(a.getStatus()))
            .filter(a -> inRange(a.getDate(), startDate, endDate)).count();
        long totalTreatments = treatmentRepository.count();
        long active = treatmentRepository.findAll().stream().filter(t->"Active".equalsIgnoreCase(t.getStatus())).count();
        long completed = treatmentRepository.findAll().stream().filter(t->"Completed".equalsIgnoreCase(t.getStatus())).count();
        long totalHospitals = hospitalRepository.count();
        long totalCapacity = hospitalRepository.findAll().stream().mapToLong(h->h.getCapacity()!=null?h.getCapacity():0L).sum();
        long totalCompliance = complianceRepository.count();
        long passed = complianceRepository.findAll().stream().filter(c->"Pass".equalsIgnoreCase(c.getResult())).count();
        long failed = complianceRepository.findAll().stream().filter(c->"Fail".equalsIgnoreCase(c.getResult())).count();
        return new DashboardResponse(totalAppts,confirmed,cancelled,totalTreatments,active,completed,
            totalHospitals,totalCapacity,totalCompliance,passed,failed);
    }

    @Transactional
    public ReportResponse generateReport(ReportRequest req) {
        if (!VALID_SCOPES.contains(req.getScope()))
            throw new RuntimeException("Invalid scope. Allowed: Appointment, Treatment, Hospital, Compliance");
        Hospital hospital = hospitalRepository.findById(req.getHospitalId())
            .orElseThrow(() -> new RuntimeException("Hospital not found: " + req.getHospitalId()));
        String metrics = buildMetrics(req.getScope(), req.getHospitalId(), hospital);
        Report report = new Report(); report.setHospital(hospital);
        report.setScope(req.getScope()); report.setMetrics(metrics);
        Report saved = reportRepository.save(report);
        return new ReportResponse(saved.getReportID(), hospital.getHospitalID(), hospital.getName(),
            saved.getScope(), saved.getMetrics(), saved.getGeneratedDate());
    }

    private boolean inRange(LocalDate date, LocalDate start, LocalDate end) {
        if (date == null) return true;
        if (start != null && date.isBefore(start)) return false;
        if (end != null && date.isAfter(end)) return false;
        return true;
    }

    private String buildMetrics(String scope, Integer hospitalId, Hospital hospital) {
        return switch (scope) {
            case "Appointment" -> {
                long c = appointmentRepository.findAll().stream().filter(a->"Confirmed".equalsIgnoreCase(a.getStatus())&&hospitalId.equals(a.getHospitalID())).count();
                long x = appointmentRepository.findAll().stream().filter(a->"Cancelled".equalsIgnoreCase(a.getStatus())&&hospitalId.equals(a.getHospitalID())).count();
                yield String.format("{\"scope\":\"Appointment\",\"hospitalId\":%d,\"confirmed\":%d,\"cancelled\":%d}",hospitalId,c,x);
            }
            case "Treatment" -> {
                long a = treatmentRepository.findAll().stream().filter(t->"Active".equalsIgnoreCase(t.getStatus())).count();
                long c = treatmentRepository.findAll().stream().filter(t->"Completed".equalsIgnoreCase(t.getStatus())).count();
                yield String.format("{\"scope\":\"Treatment\",\"hospitalId\":%d,\"active\":%d,\"completed\":%d}",hospitalId,a,c);
            }
            case "Hospital" -> String.format("{\"scope\":\"Hospital\",\"hospitalId\":%d,\"capacity\":%d}",hospitalId,hospital.getCapacity());
            case "Compliance" -> {
                long p = complianceRepository.findAll().stream().filter(c->"Pass".equalsIgnoreCase(c.getResult())).count();
                long f = complianceRepository.findAll().stream().filter(c->"Fail".equalsIgnoreCase(c.getResult())).count();
                yield String.format("{\"scope\":\"Compliance\",\"hospitalId\":%d,\"passed\":%d,\"failed\":%d}",hospitalId,p,f);
            }
            default -> "{}";
        };
    }
}
