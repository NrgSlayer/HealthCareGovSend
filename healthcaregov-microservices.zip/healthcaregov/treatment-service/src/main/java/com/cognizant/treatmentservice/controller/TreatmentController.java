package com.cognizant.treatmentservice.controller;

import com.cognizant.treatmentservice.dto.*;
import com.cognizant.treatmentservice.service.TreatmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/treatments") @RequiredArgsConstructor
public class TreatmentController {
    private final TreatmentService treatmentService;

    @PostMapping
    public ResponseEntity<TreatmentResponse> record(@Valid @RequestBody TreatmentRequest req) {
        return new ResponseEntity<>(treatmentService.record(req), HttpStatus.CREATED);
    }

    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<TreatmentResponse>> getByPatient(@PathVariable Integer patientId) {
        return ResponseEntity.ok(treatmentService.getByPatient(patientId));
    }

    @PutMapping("/patients/{patientId}")
    public ResponseEntity<PatientResponse> updatePatientRecord(
            @PathVariable Integer patientId, @Valid @RequestBody MedicalRecordUpdateRequest req) {
        return ResponseEntity.ok(treatmentService.updatePatientRecord(patientId, req));
    }
}
