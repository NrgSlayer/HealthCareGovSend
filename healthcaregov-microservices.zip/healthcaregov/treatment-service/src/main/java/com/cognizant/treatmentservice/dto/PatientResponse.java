package com.cognizant.treatmentservice.dto;
import lombok.*;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor
public class PatientResponse {
    private Integer patientID, userID;
    private String name, gender, address, contactInfo, status;
    private LocalDate dob;
}
