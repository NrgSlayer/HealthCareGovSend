package com.cognizant.treatmentservice.dto;
import lombok.*;
import java.time.LocalDate;

@Data @NoArgsConstructor @AllArgsConstructor
public class TreatmentResponse {
    private Integer treatmentID, patientID, doctorID;
    private String patientName, doctorName, diagnosis, prescription, treatmentNotes, status;
    private LocalDate date;
}
