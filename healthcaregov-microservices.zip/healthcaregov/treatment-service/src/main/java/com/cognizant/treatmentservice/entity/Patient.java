package com.cognizant.treatmentservice.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Entity @Table(name = "patient")
public class Patient {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Integer patientID;
    @OneToOne(fetch=FetchType.LAZY) @JoinColumn(name="userID") private User user;
    private String name, gender, address, contactInfo, status;
    private LocalDate dob;
}
