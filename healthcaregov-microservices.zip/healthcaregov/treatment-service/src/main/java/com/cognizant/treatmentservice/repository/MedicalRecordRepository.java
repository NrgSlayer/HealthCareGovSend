package com.cognizant.treatmentservice.repository;
import com.cognizant.treatmentservice.entity.MedicalRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface MedicalRecordRepository extends JpaRepository<MedicalRecord, Integer> {
    Optional<MedicalRecord> findByPatientPatientID(Integer patientId);
}
