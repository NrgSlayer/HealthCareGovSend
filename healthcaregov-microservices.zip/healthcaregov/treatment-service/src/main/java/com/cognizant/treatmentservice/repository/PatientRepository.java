package com.cognizant.treatmentservice.repository;
import com.cognizant.treatmentservice.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PatientRepository extends JpaRepository<Patient, Integer> {}
