package com.cognizant.treatmentservice.repository;
import com.cognizant.treatmentservice.entity.Treatment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface TreatmentRepository extends JpaRepository<Treatment, Integer> {
    List<Treatment> findByPatientPatientID(Integer patientId);
}
