package com.cognizant.treatmentservice.service;

import com.cognizant.treatmentservice.dto.*;
import com.cognizant.treatmentservice.entity.*;
import com.cognizant.treatmentservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class TreatmentService {
    private final TreatmentRepository treatmentRepository;
    private final MedicalRecordRepository medicalRecordRepository;
    private final PatientRepository patientRepository;
    private final UserRepository userRepository;

    @Transactional
    public TreatmentResponse record(TreatmentRequest req) {
        log.info("Recording treatment patientId={} doctorId={}", req.getPatientId(), req.getDoctorId());
        Patient patient = patientRepository.findById(req.getPatientId())
            .orElseThrow(() -> new RuntimeException("Patient not found: " + req.getPatientId()));
        User doctor = userRepository.findById(req.getDoctorId())
            .orElseThrow(() -> new RuntimeException("Doctor not found: " + req.getDoctorId()));
        Treatment t = new Treatment();
        t.setPatient(patient); t.setDoctor(doctor);
        t.setDiagnosis(req.getDiagnosis()); t.setPrescription(req.getPrescription());
        t.setTreatmentNotes(req.getTreatmentNotes()); t.setStatus(req.getStatus());
        Treatment saved = treatmentRepository.save(t);
        MedicalRecord record = medicalRecordRepository.findByPatientPatientID(patient.getPatientID())
            .orElse(new MedicalRecord());
        record.setPatient(patient);
        String existing = record.getDetailsJSON() != null ? record.getDetailsJSON() : "";
        record.setDetailsJSON(existing + " | Diagnosis: " + saved.getDiagnosis());
        record.setStatus(saved.getStatus());
        medicalRecordRepository.save(record);
        log.info("Treatment saved treatmentID={}", saved.getTreatmentID());
        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<TreatmentResponse> getByPatient(Integer patientId) {
        return treatmentRepository.findByPatientPatientID(patientId).stream()
            .map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional
    public PatientResponse updatePatientRecord(Integer patientId, MedicalRecordUpdateRequest req) {
        User updater = userRepository.findById(req.getUpdaterId())
            .orElseThrow(() -> new RuntimeException("Updater not found: " + req.getUpdaterId()));
        if (!updater.getRole().matches("(?i)Doctor|Admin"))
            throw new RuntimeException("Only Doctors and Admins can update patient records.");
        Patient patient = patientRepository.findById(patientId)
            .orElseThrow(() -> new RuntimeException("Patient not found: " + patientId));
        if ("Finalized".equalsIgnoreCase(patient.getStatus()))
            throw new RuntimeException("Cannot update a Finalized patient record.");
        patient.setName(req.getName()); patient.setContactInfo(req.getContactInfo()); patient.setStatus(req.getStatus());
        Patient saved = patientRepository.save(patient);
        Integer userId = saved.getUser() != null ? saved.getUser().getUserID() : null;
        return new PatientResponse(saved.getPatientID(), userId, saved.getName(),
            saved.getGender(), saved.getAddress(), saved.getContactInfo(), saved.getStatus(), saved.getDob());
    }

    private TreatmentResponse toResponse(Treatment t) {
        return new TreatmentResponse(t.getTreatmentID(), t.getPatient().getPatientID(),
            t.getDoctor().getUserID(), t.getPatient().getName(), t.getDoctor().getName(),
            t.getDiagnosis(), t.getPrescription(), t.getTreatmentNotes(), t.getStatus(), t.getDate());
    }
}
