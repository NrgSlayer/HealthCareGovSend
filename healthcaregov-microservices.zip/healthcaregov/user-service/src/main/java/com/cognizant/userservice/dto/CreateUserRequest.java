package com.cognizant.userservice.dto;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class CreateUserRequest {
    @NotBlank private String name;
    @NotBlank private String role;
    @Email @NotBlank private String email;
    private String phone;
    @NotBlank @Size(min=8) private String password;
}
