package com.cognizant.userservice.service;

import com.cognizant.userservice.dto.*;
import com.cognizant.userservice.entity.*;
import com.cognizant.userservice.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class UserService {
    private static final Set<String> VALID_STATUSES = Set.of("Active","Inactive","Rejected");
    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional(readOnly = true)
    public List<UserResponse> getUsers(String status) {
        List<User> users = (status != null && !status.isBlank())
            ? userRepository.findByStatus(status) : userRepository.findAll();
        return users.stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public UserResponse getUserById(Integer id) {
        return toResponse(userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("User not found: " + id)));
    }

    @Transactional
    public UserResponse createUser(CreateUserRequest req) {
        if (userRepository.findByEmail(req.getEmail()).isPresent())
            throw new RuntimeException("Email already exists: " + req.getEmail());
        User u = new User();
        u.setName(req.getName()); u.setRole(req.getRole());
        u.setEmail(req.getEmail()); u.setPhone(req.getPhone());
        u.setPassword(passwordEncoder.encode(req.getPassword()));
        u.setStatus("Pending");
        return toResponse(userRepository.save(u));
    }

    @Transactional
    public UserResponse updateStatus(Integer userId, UserStatusRequest req, Integer adminId) {
        if (!VALID_STATUSES.contains(req.getStatus()))
            throw new RuntimeException("Invalid status: " + req.getStatus());
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found: " + userId));
        user.setStatus(req.getStatus());
        User saved = userRepository.save(user);
        logAudit(adminId, "UPDATE_USER_STATUS", "User-" + userId);
        log.info("Admin {} updated userId={} status={}", adminId, userId, req.getStatus());
        return toResponse(saved);
    }

    private void logAudit(Integer userId, String action, String resource) {
        try {
            User u = userRepository.findById(userId).orElse(null);
            if (u != null) {
                AuditLog log = new AuditLog();
                log.setUser(u); log.setAction(action); log.setResource(resource);
                auditLogRepository.save(log);
            }
        } catch (Exception ignored) {}
    }

    private UserResponse toResponse(User u) {
        return new UserResponse(u.getUserID(), u.getName(), u.getRole(),
            u.getEmail(), u.getPhone(), u.getStatus());
    }
}
