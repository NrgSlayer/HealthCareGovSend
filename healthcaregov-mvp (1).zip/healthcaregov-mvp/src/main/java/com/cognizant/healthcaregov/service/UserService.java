package com.cognizant.healthcaregov.service;

import com.cognizant.healthcaregov.dao.PatientRepository;
import com.cognizant.healthcaregov.dao.UserRepository;
import com.cognizant.healthcaregov.dto.*;
import com.cognizant.healthcaregov.entity.User;
import com.cognizant.healthcaregov.exception.BadRequestException;
import com.cognizant.healthcaregov.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private static final Set<String> VALID_STATUSES = Set.of("Active", "Inactive", "Rejected");
    // Patient is intentionally excluded — patients must register via POST /api/patients/register
    // which creates both the User account AND the Patient profile together.
    private static final Set<String> VALID_ROLES =
            Set.of("Admin", "Doctor", "Compliance", "Auditor", "Manager");

    private final UserRepository userRepository;
    private final PatientRepository patientRepository;
    private final AuditLogService auditLogService;

    // -----------------------------------------------------------------------
    // Registration — for Admin, Doctor, Compliance, Auditor, Manager roles
    // -----------------------------------------------------------------------
    @Transactional
    public UserResponse register(UserRegisterRequest req) {
        log.info("Registering user email={} role={}", req.getEmail(), req.getRole());

        if ("Patient".equalsIgnoreCase(req.getRole())) {
            throw new BadRequestException(
                    "Patients must register via POST /api/patients/register "
                    + "(this endpoint creates both the login account and the patient profile together).");
        }
        if (!VALID_ROLES.contains(req.getRole())) {
            throw new BadRequestException(
                    "Invalid role. Allowed via this endpoint: Admin, Doctor, Compliance, Auditor, Manager");
        }
        if (userRepository.findByEmail(req.getEmail()).isPresent()) {
            throw new BadRequestException("Email already registered: " + req.getEmail());
        }

        User user = new User();
        user.setName(req.getName());
        user.setRole(req.getRole());
        user.setEmail(req.getEmail());
        user.setPhone(req.getPhone());
        user.setPassword(req.getPassword());
        // Admins are immediately Active so they can approve other users.
        // All other roles start as Pending and require admin approval.
        user.setStatus("Admin".equalsIgnoreCase(req.getRole()) ? "Active" : "Pending");

        User saved = userRepository.save(user);
        auditLogService.log(saved.getUserID(), "REGISTER", "User-" + saved.getUserID());
        log.info("User registered id={} status={}", saved.getUserID(), saved.getStatus());
        return toResponse(saved);
    }

    // -----------------------------------------------------------------------
    // USER-001: Login
    // -----------------------------------------------------------------------
    @Transactional
    public UserLoginResponse login(UserLoginRequest req) {
        log.info("Login attempt email={}", req.getEmail());
        User user = userRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new BadRequestException("Invalid credentials."));

        if (!req.getPassword().equals(user.getPassword())) {
            auditLogService.log(user.getUserID(), "LOGIN_FAILED", "User-" + user.getUserID());
            throw new BadRequestException("Invalid credentials.");
        }
        if (!"Active".equalsIgnoreCase(user.getStatus())) {
            throw new BadRequestException(
                    "Account is not active. Current status: " + user.getStatus()
                    + ". Contact an admin to approve your account.");
        }

        // For Patient role, include the patientID so they can use patient-specific endpoints
        Integer patientId = null;
        if ("Patient".equalsIgnoreCase(user.getRole())) {
            patientId = patientRepository.findByUserUserID(user.getUserID())
                    .map(p -> p.getPatientID())
                    .orElse(null);
        }

        auditLogService.log(user.getUserID(), "LOGIN", "User-" + user.getUserID());
        log.info("User {} logged in successfully", user.getUserID());
        return new UserLoginResponse(user.getUserID(), patientId, user.getName(),
                user.getRole(), user.getEmail(), user.getStatus(), "Login successful.");
    }

    // -----------------------------------------------------------------------
    // USER-002: Logout
    // -----------------------------------------------------------------------
    @Transactional
    public void logout(Integer userId) {
        log.info("Logout for userId={}", userId);
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User not found with id: " + userId);
        }
        auditLogService.log(userId, "LOGOUT", "User-" + userId);
    }

    // -----------------------------------------------------------------------
    // HADM-009: View users (all roles, optionally filter by status)
    // -----------------------------------------------------------------------
    @Transactional(readOnly = true)
    public List<UserResponse> getUsers(String status) {
        log.info("Fetching users status={}", status);
        List<User> users = (status != null && !status.isBlank())
                ? userRepository.findByStatus(status)
                : userRepository.findAll();
        return users.stream().map(this::toResponse).collect(Collectors.toList());
    }

    // -----------------------------------------------------------------------
    // HADM-009: Approve → Active | Reject → Rejected | Deactivate → Inactive | Reactivate → Active
    // -----------------------------------------------------------------------
    @Transactional
    public UserResponse updateStatus(Integer userId, UserStatusRequest req, Integer adminId) {
        log.info("Admin {} updating status of userId={} to {}", adminId, userId, req.getStatus());
        if (!VALID_STATUSES.contains(req.getStatus())) {
            throw new BadRequestException("Invalid status. Allowed: Active, Inactive, Rejected");
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        user.setStatus(req.getStatus());
        User saved = userRepository.save(user);
        auditLogService.log(adminId, "STATUS_CHANGE:" + req.getStatus(), "User-" + userId);
        return toResponse(saved);
    }

    // -----------------------------------------------------------------------
    // Helper
    // -----------------------------------------------------------------------
    private UserResponse toResponse(User u) {
        return new UserResponse(u.getUserID(), u.getName(), u.getRole(),
                u.getEmail(), u.getPhone(), u.getStatus());
    }
}
