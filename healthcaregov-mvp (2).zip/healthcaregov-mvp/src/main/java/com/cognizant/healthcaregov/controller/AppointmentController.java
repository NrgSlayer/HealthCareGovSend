package com.cognizant.healthcaregov.controller;

import com.cognizant.healthcaregov.dto.AppointmentBookRequest;
import com.cognizant.healthcaregov.dto.AppointmentCancelRequest;
import com.cognizant.healthcaregov.dto.AppointmentReassignRequest;
import com.cognizant.healthcaregov.dto.AppointmentResponse;
import com.cognizant.healthcaregov.service.AppointmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/appointments")
@RequiredArgsConstructor
public class AppointmentController {

    private final AppointmentService appointmentService;

    /** PAT-004 – Book appointment */
    @PostMapping("/book")
    public ResponseEntity<AppointmentResponse> book(
            @Valid @RequestBody AppointmentBookRequest req) {
        log.info("POST /api/appointments/book patientId={}", req.getPatientID());
        return new ResponseEntity<>(appointmentService.book(req), HttpStatus.CREATED);
    }

    /** PAT-005 – Cancel appointment */
    @PutMapping("/cancel")
    public ResponseEntity<AppointmentResponse> cancel(
            @Valid @RequestBody AppointmentCancelRequest req) {
        log.info("PUT /api/appointments/cancel id={}", req.getAppointmentID());
        return ResponseEntity.ok(appointmentService.cancel(req));
    }

    /** DOC-001 – Doctor views their appointment schedule */
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<AppointmentResponse>> getByDoctor(
            @PathVariable Integer doctorId) {
        return ResponseEntity.ok(appointmentService.getByDoctor(doctorId));
    }

    /** HADM-010 – Admin views all appointments */
    @GetMapping
    public ResponseEntity<List<AppointmentResponse>> getAll() {
        return ResponseEntity.ok(appointmentService.getAll());
    }

    /** HADM-010 – Admin reassigns appointment to different doctor */
    @PutMapping("/{appointmentId}/reassign")
    public ResponseEntity<AppointmentResponse> reassign(
            @PathVariable Integer appointmentId,
            @Valid @RequestBody AppointmentReassignRequest req,
            @RequestParam Integer adminId) {
        return ResponseEntity.ok(
                appointmentService.reassign(appointmentId, req.getNewDoctorId(), adminId));
    }

    /** HADM-011 – Admin checks in patient (status → Arrived) */
    @PutMapping("/{appointmentId}/checkin")
    public ResponseEntity<AppointmentResponse> checkIn(
            @PathVariable Integer appointmentId,
            @RequestParam Integer adminId) {
        log.info("PUT /api/appointments/{}/checkin adminId={}", appointmentId, adminId);
        return ResponseEntity.ok(appointmentService.checkIn(appointmentId, adminId));
    }
}
