package com.cognizant.healthcaregov.controller;

import com.cognizant.healthcaregov.dto.HospitalRequest;
import com.cognizant.healthcaregov.dto.HospitalResponse;
import com.cognizant.healthcaregov.service.HospitalService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/hospitals")
@RequiredArgsConstructor
public class HospitalController {

    private final HospitalService hospitalService;

    /** HADM-001 – Add hospital */
    @PostMapping
    public ResponseEntity<HospitalResponse> create(@Valid @RequestBody HospitalRequest req) {
        log.info("POST /api/hospitals");
        return new ResponseEntity<>(hospitalService.create(req), HttpStatus.CREATED);
    }

    /** HADM-002 – View all hospitals */
    @GetMapping
    public ResponseEntity<List<HospitalResponse>> getAll() {
        return ResponseEntity.ok(hospitalService.getAll());
    }

    /** HADM-002 – View hospital by ID */
    @GetMapping("/{id}")
    public ResponseEntity<HospitalResponse> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(hospitalService.getById(id));
    }

    /** HADM-002 – Search hospitals */
    @GetMapping("/search")
    public ResponseEntity<List<HospitalResponse>> search(@RequestParam String query) {
        return ResponseEntity.ok(hospitalService.search(query));
    }

    /** HADM-003 – Edit hospital */
    @PutMapping("/{id}")
    public ResponseEntity<HospitalResponse> update(
            @PathVariable Integer id, @Valid @RequestBody HospitalRequest req) {
        return ResponseEntity.ok(hospitalService.update(id, req));
    }

    /** HADM-003 – Delete hospital */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        hospitalService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
