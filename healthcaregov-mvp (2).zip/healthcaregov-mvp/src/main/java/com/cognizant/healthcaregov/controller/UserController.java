package com.cognizant.healthcaregov.controller;

import com.cognizant.healthcaregov.dto.*;
import com.cognizant.healthcaregov.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // -----------------------------------------------------------------------
    // Registration — no auth required, open to all
    // -----------------------------------------------------------------------

    /**
     * Register any system user (Admin / Doctor / Patient / Compliance / Auditor / Manager).
     *
     * Status rules:
     *   - Admin  → immediately Active (can log in right away and approve others)
     *   - Others → Pending (admin must approve via PUT /api/users/{id}/status before they can log in)
     *
     * Roles: Admin | Doctor | Patient | Compliance | Auditor | Manager
     */
    @PostMapping("/register")
    public ResponseEntity<UserResponse> register(@Valid @RequestBody UserRegisterRequest req) {
        log.info("POST /api/users/register role={}", req.getRole());
        return new ResponseEntity<>(userService.register(req), HttpStatus.CREATED);
    }

    // -----------------------------------------------------------------------
    // USER-001 — Login
    // -----------------------------------------------------------------------
    @PostMapping("/login")
    public ResponseEntity<UserLoginResponse> login(@Valid @RequestBody UserLoginRequest req) {
        log.info("POST /api/users/login");
        return ResponseEntity.ok(userService.login(req));
    }

    // -----------------------------------------------------------------------
    // USER-002 — Logout
    // -----------------------------------------------------------------------
    @PostMapping("/logout/{userId}")
    public ResponseEntity<String> logout(@PathVariable Integer userId) {
        log.info("POST /api/users/logout/{}", userId);
        userService.logout(userId);
        return ResponseEntity.ok("Logged out successfully.");
    }

    // -----------------------------------------------------------------------
    // HADM-009 — User lifecycle management
    // -----------------------------------------------------------------------

    /** List all users. Use ?status=Pending to see accounts awaiting approval. */
    @GetMapping
    public ResponseEntity<List<UserResponse>> getUsers(
            @RequestParam(required = false) String status) {
        return ResponseEntity.ok(userService.getUsers(status));
    }

    /**
     * Approve   → { "status": "Active" }
     * Reject    → { "status": "Rejected" }
     * Deactivate→ { "status": "Inactive" }
     * Reactivate→ { "status": "Active" }
     */
    @PutMapping("/{userId}/status")
    public ResponseEntity<UserResponse> updateStatus(
            @PathVariable Integer userId,
            @Valid @RequestBody UserStatusRequest req,
            @RequestParam Integer adminId) {
        return ResponseEntity.ok(userService.updateStatus(userId, req, adminId));
    }
}
