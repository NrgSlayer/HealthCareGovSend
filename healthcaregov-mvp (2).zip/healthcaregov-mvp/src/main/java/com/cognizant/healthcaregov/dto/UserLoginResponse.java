package com.cognizant.healthcaregov.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserLoginResponse {
    private Integer userID;
    private Integer patientID;  // Non-null only when role = Patient
    private String  name;
    private String  role;
    private String  email;
    private String  status;
    private String  token;      // JWT Bearer token
    private String  message;
}
