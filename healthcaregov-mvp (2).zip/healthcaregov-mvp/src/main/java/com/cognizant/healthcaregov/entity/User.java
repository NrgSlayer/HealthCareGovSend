package com.cognizant.healthcaregov.entity;

import jakarta.persistence.*;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userID;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String role; // Patient | Doctor | Admin | Manager | Compliance | Auditor

    @Column(unique = true, nullable = false)
    private String email;

    private String phone;

    @Column(nullable = false)
    private String status; // Pending | Active | Inactive | Rejected

    @Column(nullable = false)
    private String password;
}
