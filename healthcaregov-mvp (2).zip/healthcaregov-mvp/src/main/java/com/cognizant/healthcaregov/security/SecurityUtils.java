package com.cognizant.healthcaregov.security;

import com.cognizant.healthcaregov.dao.UserRepository;
import com.cognizant.healthcaregov.entity.User;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Helper component for reading the currently authenticated user from the
 * Spring SecurityContext. Used by service-layer ownership checks.
 */
@Component
@RequiredArgsConstructor
public class SecurityUtils {

    private final UserRepository userRepository;

    /**
     * Returns the email (username) of the currently authenticated user,
     * or empty if the security context has no principal.
     */
    public Optional<String> getCurrentUserEmail() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated()
                || "anonymousUser".equals(auth.getPrincipal())) {
            return Optional.empty();
        }
        return Optional.of(auth.getName());
    }

    /**
     * Returns the User entity for the currently authenticated user.
     */
    public Optional<User> getCurrentUser() {
        return getCurrentUserEmail().flatMap(userRepository::findByEmail);
    }

    /**
     * Returns true if the currently authenticated user has the given role.
     * Role should be passed WITHOUT the "ROLE_" prefix (e.g. "ADMIN", "DOCTOR").
     */
    public boolean hasRole(String role) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null) return false;
        return auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_" + role.toUpperCase()));
    }

    /**
     * Returns true if the currently authenticated user is an Admin.
     */
    public boolean isAdmin() {
        return hasRole("ADMIN");
    }
}
