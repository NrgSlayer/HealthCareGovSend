package com.cognizant.healthcaregov.security;

import com.cognizant.healthcaregov.dao.UserRepository;
import com.cognizant.healthcaregov.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    /**
     * Loads a user by email (used as username in this application).
     * Spring Security calls this during JWT filter validation.
     */
    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException(
                        "User not found with email: " + email));

        log.debug("UserDetails loaded for email={} role={}", email, user.getRole());

        // Role is stored as "Admin", "Doctor", etc.
        // Spring Security expects "ROLE_ADMIN", "ROLE_DOCTOR", etc. for hasRole() checks.
        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getEmail())
                .password(user.getPassword())
                .authorities(List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().toUpperCase())))
                .accountExpired(false)
                .accountLocked("Inactive".equalsIgnoreCase(user.getStatus())
                        || "Rejected".equalsIgnoreCase(user.getStatus()))
                .credentialsExpired(false)
                .disabled("Pending".equalsIgnoreCase(user.getStatus()))
                .build();
    }
}
