package com.cognizant.healthcaregov.service;

import com.cognizant.healthcaregov.dao.PatientRepository;
import com.cognizant.healthcaregov.dao.UserRepository;
import com.cognizant.healthcaregov.dto.*;
import com.cognizant.healthcaregov.entity.User;
import com.cognizant.healthcaregov.exception.BadRequestException;
import com.cognizant.healthcaregov.exception.ResourceNotFoundException;
import com.cognizant.healthcaregov.security.JwtUtils;
import com.cognizant.healthcaregov.security.SecurityUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private static final Set<String> VALID_STATUSES = Set.of("Active", "Inactive", "Rejected");
    private static final Set<String> VALID_ROLES    =
            Set.of("Admin", "Doctor", "Compliance", "Auditor", "Manager");

    private final UserRepository        userRepository;
    private final PatientRepository     patientRepository;
    private final AuditLogService       auditLogService;
    private final PasswordEncoder       passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtils              jwtUtils;
    private final SecurityUtils         securityUtils;

    // -----------------------------------------------------------------------
    // Registration — Admin, Doctor, Compliance, Auditor, Manager
    // -----------------------------------------------------------------------
    @Transactional
    public UserResponse register(UserRegisterRequest req) {
        log.info("Registering user email={} role={}", req.getEmail(), req.getRole());

        if ("Patient".equalsIgnoreCase(req.getRole())) {
            throw new BadRequestException(
                    "Patients must register via POST /api/patients/register.");
        }
        if (!VALID_ROLES.contains(req.getRole())) {
            throw new BadRequestException(
                    "Invalid role. Allowed: Admin, Doctor, Compliance, Auditor, Manager");
        }
        if (userRepository.findByEmail(req.getEmail()).isPresent()) {
            throw new BadRequestException("Email already registered: " + req.getEmail());
        }

        User user = new User();
        user.setName(req.getName());
        user.setRole(req.getRole());
        user.setEmail(req.getEmail());
        user.setPhone(req.getPhone());
        user.setPassword(passwordEncoder.encode(req.getPassword()));
        user.setStatus("Admin".equalsIgnoreCase(req.getRole()) ? "Active" : "Pending");

        User saved = userRepository.save(user);
        auditLogService.log(saved.getUserID(), "REGISTER", "User-" + saved.getUserID());
        log.info("User registered id={} status={}", saved.getUserID(), saved.getStatus());
        return toResponse(saved);
    }

    // -----------------------------------------------------------------------
    // USER-001: Login
    // -----------------------------------------------------------------------
    @Transactional
    public UserLoginResponse login(UserLoginRequest req) {
        log.info("Login attempt email={}", req.getEmail());

        User user = userRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new BadRequestException("Invalid credentials."));

        if ("Pending".equalsIgnoreCase(user.getStatus())) {
            throw new BadRequestException(
                    "Account is pending approval. Contact an admin to activate your account.");
        }
        if ("Inactive".equalsIgnoreCase(user.getStatus())
                || "Rejected".equalsIgnoreCase(user.getStatus())) {
            throw new BadRequestException(
                    "Account is not active. Current status: " + user.getStatus());
        }

        Authentication authentication;
        try {
            authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));
        } catch (AuthenticationException ex) {
            auditLogService.log(user.getUserID(), "LOGIN_FAILED", "User-" + user.getUserID());
            throw new BadRequestException("Invalid credentials.");
        }

        String token = jwtUtils.generateToken(authentication);

        Integer patientId = null;
        if ("Patient".equalsIgnoreCase(user.getRole())) {
            patientId = patientRepository.findByUserUserID(user.getUserID())
                    .map(p -> p.getPatientID())
                    .orElse(null);
        }

        auditLogService.log(user.getUserID(), "LOGIN", "User-" + user.getUserID());
        log.info("User {} logged in. Token issued.", user.getUserID());

        return new UserLoginResponse(user.getUserID(), patientId, user.getName(),
                user.getRole(), user.getEmail(), user.getStatus(), token, "Login successful.");
    }

    // -----------------------------------------------------------------------
    // USER-002: Logout
    // BUG-3 FIX: A user may only log out their OWN session.
    //            Admin may log out any user.
    // -----------------------------------------------------------------------
    @Transactional
    public void logout(Integer userId) {
        log.info("Logout for userId={}", userId);

        User target = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found with id: " + userId));

        if (!securityUtils.isAdmin()) {
            String callerEmail = securityUtils.getCurrentUserEmail().orElse(null);
            if (!target.getEmail().equalsIgnoreCase(callerEmail)) {
                log.warn("Logout denied: {} tried to logout userId={}", callerEmail, userId);
                throw new BadRequestException(
                        "Access denied: you may only log out your own session.");
            }
        }

        auditLogService.log(userId, "LOGOUT", "User-" + userId);
        log.info("User {} logged out.", userId);
    }

    // -----------------------------------------------------------------------
    // HADM-009: List users — optionally filter by status
    // -----------------------------------------------------------------------
    @Transactional(readOnly = true)
    public List<UserResponse> getUsers(String status) {
        log.info("Fetching users status={}", status);
        List<User> users = (status != null && !status.isBlank())
                ? userRepository.findByStatus(status)
                : userRepository.findAll();
        return users.stream().map(this::toResponse).collect(Collectors.toList());
    }

    // -----------------------------------------------------------------------
    // HADM-009: Update user status
    // -----------------------------------------------------------------------
    @Transactional
    public UserResponse updateStatus(Integer userId, UserStatusRequest req, Integer adminId) {
        log.info("Admin {} updating status of userId={} to {}", adminId, userId, req.getStatus());
        if (!VALID_STATUSES.contains(req.getStatus())) {
            throw new BadRequestException("Invalid status. Allowed: Active, Inactive, Rejected");
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found with id: " + userId));
        user.setStatus(req.getStatus());
        User saved = userRepository.save(user);
        auditLogService.log(adminId, "STATUS_CHANGE:" + req.getStatus(), "User-" + userId);
        return toResponse(saved);
    }

    // -----------------------------------------------------------------------
    // Helper
    // -----------------------------------------------------------------------
    private UserResponse toResponse(User u) {
        return new UserResponse(u.getUserID(), u.getName(), u.getRole(),
                u.getEmail(), u.getPhone(), u.getStatus());
    }
}
