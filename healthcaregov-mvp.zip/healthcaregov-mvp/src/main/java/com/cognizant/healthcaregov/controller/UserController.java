package com.cognizant.healthcaregov.controller;

import com.cognizant.healthcaregov.dto.*;
import com.cognizant.healthcaregov.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    /** USER-001 – Login */
    @PostMapping("/login")
    public ResponseEntity<UserLoginResponse> login(@Valid @RequestBody UserLoginRequest req) {
        log.info("POST /api/users/login");
        return ResponseEntity.ok(userService.login(req));
    }

    /** USER-002 – Logout */
    @PostMapping("/logout/{userId}")
    public ResponseEntity<String> logout(@PathVariable Integer userId) {
        log.info("POST /api/users/logout/{}", userId);
        userService.logout(userId);
        return ResponseEntity.ok("Logged out successfully.");
    }

    /** HADM-009 – List users; ?status=Pending to see pending accounts */
    @GetMapping
    public ResponseEntity<List<UserResponse>> getUsers(
            @RequestParam(required = false) String status) {
        return ResponseEntity.ok(userService.getUsers(status));
    }

    /** HADM-009 – Approve / Reject / Deactivate / Reactivate */
    @PutMapping("/{userId}/status")
    public ResponseEntity<UserResponse> updateStatus(
            @PathVariable Integer userId,
            @Valid @RequestBody UserStatusRequest req,
            @RequestParam Integer adminId) {
        return ResponseEntity.ok(userService.updateStatus(userId, req, adminId));
    }
}
