package com.cognizant.healthcaregov.service;

import com.cognizant.healthcaregov.dao.PatientDocumentRepository;
import com.cognizant.healthcaregov.dao.PatientRepository;
import com.cognizant.healthcaregov.dao.TreatmentRepository;
import com.cognizant.healthcaregov.dao.MedicalRecordRepository;
import com.cognizant.healthcaregov.dto.*;
import com.cognizant.healthcaregov.entity.Patient;
import com.cognizant.healthcaregov.entity.PatientDocument;
import com.cognizant.healthcaregov.exception.BadRequestException;
import com.cognizant.healthcaregov.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PatientService {

    private static final Set<String> ALLOWED_DOC_TYPES = Set.of("IDProof", "HealthCard");

    private final PatientRepository patientRepository;
    private final PatientDocumentRepository documentRepository;
    private final TreatmentRepository treatmentRepository;
    private final MedicalRecordRepository medicalRecordRepository;

    // PAT-001: Register patient
    @Transactional
    public PatientResponse register(PatientRegisterRequest req) {
        log.info("Registering new patient: {}", req.getName());
        Patient patient = new Patient();
        patient.setName(req.getName());
        patient.setDob(LocalDate.parse(req.getDob()));
        patient.setGender(req.getGender());
        patient.setAddress(req.getAddress());
        patient.setContactInfo(req.getContactInfo());
        patient.setStatus("Active");
        Patient saved = patientRepository.save(patient);
        log.info("Patient registered with ID={}", saved.getPatientID());
        return toResponse(saved);
    }

    // PAT-003: View profile
    @Transactional(readOnly = true)
    public PatientResponse getProfile(Integer patientId) {
        log.info("Fetching profile for patientId={}", patientId);
        return toResponse(findById(patientId));
    }

    // PAT-003: Update profile (address + contactInfo only)
    @Transactional
    public PatientResponse updateProfile(Integer patientId, PatientUpdateRequest req) {
        log.info("Updating profile for patientId={}", patientId);
        Patient patient = findById(patientId);
        patient.setAddress(req.getAddress());
        patient.setContactInfo(req.getContactInfo());
        return toResponse(patientRepository.save(patient));
    }

    // PAT-002: Upload document
    @Transactional
    public DocumentResponse uploadDocument(DocumentUploadRequest req) {
        log.info("Uploading document for patientId={}", req.getPatientID());
        if (!ALLOWED_DOC_TYPES.contains(req.getDocType())) {
            throw new BadRequestException("Invalid docType. Allowed: IDProof, HealthCard");
        }
        Patient patient = findById(req.getPatientID());
        PatientDocument doc = new PatientDocument();
        doc.setPatient(patient);
        doc.setDocType(req.getDocType());
        doc.setFileURI(req.getFileURI());
        doc.setVerificationStatus("Pending");
        PatientDocument saved = documentRepository.save(doc);
        log.info("Document saved with ID={}", saved.getDocumentID());
        return new DocumentResponse(saved.getDocumentID(), patient.getPatientID(),
                saved.getDocType(), saved.getFileURI(), saved.getUploadedDate(),
                saved.getVerificationStatus());
    }

    // PAT-006: View medical history (treatments)
    @Transactional(readOnly = true)
    public List<TreatmentResponse> getMedicalHistory(Integer patientId) {
        log.info("Fetching medical history for patientId={}", patientId);
        if (!patientRepository.existsById(patientId)) {
            throw new ResourceNotFoundException("Patient not found with id: " + patientId);
        }
        return treatmentRepository.findByPatientPatientID(patientId).stream()
                .map(t -> new TreatmentResponse(
                        t.getTreatmentID(),
                        t.getPatient().getPatientID(), t.getPatient().getName(),
                        t.getDoctor().getUserID(), t.getDoctor().getName(),
                        t.getDiagnosis(), t.getPrescription(), t.getTreatmentNotes(),
                        t.getDate(), t.getStatus()))
                .collect(Collectors.toList());
    }

    // PAT-006: View medical summary record
    @Transactional(readOnly = true)
    public MedicalSummaryResponse getMedicalSummary(Integer patientId) {
        log.info("Fetching medical summary for patientId={}", patientId);
        return medicalRecordRepository.findByPatientPatientID(patientId)
                .map(r -> new MedicalSummaryResponse(
                        r.getRecordID(),
                        r.getPatient().getPatientID(), r.getPatient().getName(),
                        r.getPatient().getContactInfo(),
                        r.getDetailsJSON(), r.getDate(), r.getStatus()))
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No medical record found for patientId: " + patientId));
    }

    private Patient findById(Integer id) {
        return patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with id: " + id));
    }

    private PatientResponse toResponse(Patient p) {
        return new PatientResponse(p.getPatientID(), p.getName(), p.getDob(),
                p.getGender(), p.getAddress(), p.getContactInfo(), p.getStatus());
    }
}
