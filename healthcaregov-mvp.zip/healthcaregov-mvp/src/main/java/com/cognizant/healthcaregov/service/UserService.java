package com.cognizant.healthcaregov.service;

import com.cognizant.healthcaregov.dao.UserRepository;
import com.cognizant.healthcaregov.dto.*;
import com.cognizant.healthcaregov.entity.User;
import com.cognizant.healthcaregov.exception.BadRequestException;
import com.cognizant.healthcaregov.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

    private static final Set<String> VALID_STATUSES = Set.of("Active", "Inactive", "Rejected");

    private final UserRepository userRepository;
    private final AuditLogService auditLogService;

    // USER-001: Login
    @Transactional
    public UserLoginResponse login(UserLoginRequest req) {
        log.info("Login attempt for email={}", req.getEmail());
        User user = userRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new BadRequestException("Invalid credentials."));

        if (!req.getPassword().equals(user.getPassword())) {
            auditLogService.log(user.getUserID(), "LOGIN_FAILED", "User-" + user.getUserID());
            throw new BadRequestException("Invalid credentials.");
        }
        if (!"Active".equalsIgnoreCase(user.getStatus())) {
            throw new BadRequestException("Account is not active. Current status: " + user.getStatus());
        }
        auditLogService.log(user.getUserID(), "LOGIN", "User-" + user.getUserID());
        log.info("User {} logged in successfully", user.getUserID());
        return new UserLoginResponse(user.getUserID(), user.getName(), user.getRole(),
                user.getEmail(), user.getStatus(), "Login successful.");
    }

    // USER-002: Logout
    @Transactional
    public void logout(Integer userId) {
        log.info("Logout for userId={}", userId);
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User not found with id: " + userId);
        }
        auditLogService.log(userId, "LOGOUT", "User-" + userId);
    }

    // HADM-009: View users (optionally filter by status)
    @Transactional(readOnly = true)
    public List<UserResponse> getUsers(String status) {
        log.info("Fetching users with status={}", status);
        List<User> users = (status != null && !status.isBlank())
                ? userRepository.findByStatus(status)
                : userRepository.findAll();
        return users.stream().map(this::toResponse).collect(Collectors.toList());
    }

    // HADM-009: Approve / Reject / Deactivate / Reactivate
    @Transactional
    public UserResponse updateStatus(Integer userId, UserStatusRequest req, Integer adminId) {
        log.info("Admin {} changing status of userId={} to {}", adminId, userId, req.getStatus());
        if (!VALID_STATUSES.contains(req.getStatus())) {
            throw new BadRequestException("Invalid status. Allowed: Active, Inactive, Rejected");
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        user.setStatus(req.getStatus());
        User saved = userRepository.save(user);
        auditLogService.log(adminId, "STATUS_CHANGE:" + req.getStatus(), "User-" + userId);
        return toResponse(saved);
    }

    private UserResponse toResponse(User u) {
        return new UserResponse(u.getUserID(), u.getName(), u.getRole(),
                u.getEmail(), u.getPhone(), u.getStatus());
    }
}
